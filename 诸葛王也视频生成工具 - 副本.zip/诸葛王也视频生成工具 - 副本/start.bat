@echo off
cd /d "%~dp0"

echo ==============================================
echo ZG-WangYe AI DRAMA STUDIO - Start Script
echo ==============================================


if exist "%~dp0node-env\node.exe" (
    echo [INFO] Detected local Node.js engine in /node-env.
    set "PATH=%~dp0node-env;%PATH%"
)
:: -------------------------------

echo Checking Node.js environment...
node -v >nul 2>&1
if errorlevel 1 goto NONODE

if not exist package.json goto NOPKG

if exist node_modules\ goto STARTAPP

echo [INFO] Dependencies missing. Installing...

call npm config set registry https://registry.npmmirror.com
call npm install --no-fund --no-audit
if errorlevel 1 goto FAIL_INSTALL

:STARTAPP
echo.
echo Starting Local Server...
echo Please open http://localhost:3000 in your browser!
echo ==============================================
echo.
call npm run dev
echo.
echo Server has stopped or crashed. See any errors above.
pause
exit /b

:NONODE
echo [ERROR] Node.js is not found in system or local folder!
echo.
echo [INFO] Attempting to install Node.js automatically via winget...
echo [TIP] If a prompt appears, please click "Yes" to allow installation.
echo.

winget install -e --id OpenJS.NodeJS.LTS --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo.
    echo ----------------------------------------------------------------
    echo [CRITICAL ERROR] Automatic installation failed!
    echo.
    echo [SOLUTION 1] Right-click start.bat and select "Run as Administrator"
    echo [SOLUTION 2] Manually download and install from: https://nodejs.org/
    echo [SOLUTION 3] Use Portable Mode:
    echo   1. Download Node.js Windows Zip from nodejs.org
    echo   2. Extract content into a folder named "node-env" here.
    echo ----------------------------------------------------------------
) else (
    echo.
    echo [SUCCESS] Node.js installed! Please RESTART this start.bat.
)
pause
exit /b

:NOPKG
echo [ERROR] package.json not found! Please run from the exact project folder.
pause
exit /b

:FAIL_INSTALL
echo [ERROR] npm install failed. Please check your network connection.
pause
exit /b
