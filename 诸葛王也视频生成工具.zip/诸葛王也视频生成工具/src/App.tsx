import { useState } from 'react';
import { Settings, Image as ImageIcon, ListVideo, Settings2, Film, Wand2, Terminal, X, Globe } from 'lucide-react';
import { useStore } from '@/store/useStore';

// Sections
import PromptGenerator from '@/components/sections/PromptGenerator';
import AssetLibrary from '@/components/sections/AssetLibrary';
import StoryboardGenerator from '@/components/sections/StoryboardGenerator';
import VideoSettings from '@/components/sections/VideoSettings';
import VideoGallery from '@/components/sections/VideoGallery';
import GlobalSettings from '@/components/sections/GlobalSettings';
import LogPanel from '@/components/LogPanel';
import TaskPoller from '@/components/TaskPoller';

const STEPS = [
  { id: 'global', label: '1. 全局配置', icon: Globe },
  { id: 'assets', label: '2. 资产库', icon: ImageIcon },
  { id: 'storyboard', label: '3. 分镜生成', icon: ListVideo },
  { id: 'settings', label: '4. 视频设置', icon: Settings2 },
  { id: 'gallery', label: '5. 视频展示', icon: Film },
];

export default function App() {
  const [activeStep, setActiveStep] = useState('global'); // Default to global
  const [showLogs, setShowLogs] = useState(false);
  const [isPromptGeneratorOpen, setIsPromptGeneratorOpen] = useState(false);
  const { logs, clearLogs } = useStore();

  // Hidden anti-counterfeiting watermark
  if (typeof window !== 'undefined') {
    (window as any).__ZGWY_SIGNATURE__ = 'zhugewangye';
  }

  return (
    <div className="h-screen w-screen bg-[var(--color-app-bg)] text-[var(--color-app-text)] flex font-sans overflow-hidden">
      {/* Left Sidebar */}
      <aside className="w-64 bg-[var(--color-app-sidebar)] border-r border-[var(--color-app-border)] flex flex-col shrink-0">
        <div className="h-[60px] px-6 flex items-center border-b border-[var(--color-app-border)]">
          <div className="font-bold tracking-tight text-lg flex items-center gap-2">
            <span className="text-[var(--color-app-accent)]">诸葛</span>王也
          </div>
        </div>
        
        <div className="flex-1 py-6 px-4 flex flex-col gap-2 overflow-y-auto custom-scrollbar">
          <div className="text-xs font-semibold text-[var(--color-app-text-dim)] uppercase tracking-wider mb-2 px-2">
            创作流程
          </div>
          {STEPS.map((step) => {
            const Icon = step.icon;
            const isActive = activeStep === step.id;
            return (
              <button
                key={step.id}
                onClick={() => setActiveStep(step.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-medium ${
                  isActive 
                    ? 'bg-[var(--color-app-accent)] text-white shadow-[0_0_15px_rgba(79,70,229,0.3)]' 
                    : 'text-[var(--color-app-text-dim)] hover:bg-[var(--color-app-card)] hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {step.label}
              </button>
            );
          })}
        </div>
      </aside>

      {/* Main Workspace */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[var(--color-app-bg)]">
        <header className="h-[60px] px-6 flex items-center justify-between border-b border-[var(--color-app-border)] shrink-0 bg-[var(--color-app-card)]/30">
          <h2 className="font-semibold text-lg">
            {STEPS.find(s => s.id === activeStep)?.label}
          </h2>
          <div className="flex gap-3">
            <button 
              onClick={() => setIsPromptGeneratorOpen(true)}
              className="flex items-center gap-1.5 bg-zinc-800/80 text-indigo-400 px-3 py-1.5 rounded-md text-sm font-medium hover:bg-zinc-700/80 border border-indigo-500/30 transition-colors shadow-sm"
            >
              <Wand2 size={16} /> 提示词生成
            </button>
            {activeStep === 'gallery' && (
              <button className="bg-[var(--color-app-accent)] text-white px-4 py-1.5 rounded-md text-xs font-semibold hover:bg-indigo-500 transition-colors">
                批量导出视频
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 flex flex-col overflow-hidden relative">
          <div className="flex-1 overflow-hidden relative">
            {activeStep === 'global' && <div className="h-full p-6 overflow-y-auto custom-scrollbar"><GlobalSettings /></div>}
            {activeStep === 'assets' && <div className="h-full p-6 overflow-hidden"><AssetLibrary /></div>}
            {activeStep === 'storyboard' && <div className="h-full p-6 overflow-y-auto custom-scrollbar"><StoryboardGenerator /></div>}
            {activeStep === 'settings' && <div className="h-full p-6 overflow-y-auto custom-scrollbar"><VideoSettings /></div>}
            {activeStep === 'gallery' && <div className="h-full p-6 overflow-y-auto custom-scrollbar"><VideoGallery /></div>}
            <LogPanel />
            <TaskPoller />

            {/* Floating Prompt Generator */}
            {isPromptGeneratorOpen && (
              <div className="absolute inset-0 z-50 bg-black/60 flex items-center justify-center p-4 lg:p-8 backdrop-blur-sm animate-in fade-in duration-200">
                <div className="relative w-full h-full max-w-[1400px] bg-zinc-950 rounded-2xl overflow-hidden shadow-2xl border border-zinc-800 flex flex-col animate-in zoom-in-95 duration-200">
                  <button 
                    onClick={() => setIsPromptGeneratorOpen(false)}
                    className="absolute top-4 right-4 z-50 p-2 bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-full transition-colors shadow-lg border border-zinc-700/50"
                    aria-label="关闭"
                  >
                    <X size={20} />
                  </button>
                  <div className="flex-1 overflow-hidden">
                    <PromptGenerator />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
