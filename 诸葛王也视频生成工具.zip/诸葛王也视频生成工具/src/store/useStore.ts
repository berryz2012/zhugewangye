import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export type Category = '男生' | '女生' | '服装' | '场景' | '道具' | '音频' | '其他';

export interface Asset {
  id: string;
  name: string;
  category: Category;
  tags: string[];
  type: 'image' | 'audio';
  originalUrl: string;
  processedUrl?: string | null;
}

export interface Favorite {
  id: string;
  name: string;
  prompt: string;
  translation: string;
}

export interface Shot {
  id: string;
  description: string;
}

export interface LinkedAsset {
  id: string;
  assetId: string;
  name: string;
  type: 'image' | 'audio';
  role: 'reference_image' | 'first_frame' | 'last_frame' | 'reference_audio';
}

export interface ScenePromptTemplate {
  id: string;
  name: string;
  content: string;
}

export interface Act {
  id: string;
  index: number;
  title: string;
  originalText?: string;
  characters: string[];
  shotsGenerated: boolean;
  shots: Shot[];
  customShots?: Shot[];
  linkedAssets: LinkedAsset[];
  status: 'idle' | 'queued' | 'generating' | 'done' | 'error';
  taskId?: string;
  videoUrl?: string; // Latest video URL
  videoHistory?: string[]; // All generated video URLs for this act
  duration: number;
  resolution: '480p' | '720p';
  ratio: '21:9' | '16:9' | '4:3' | '1:1' | '3:4' | '9:16';
  errorReason?: string;
  scenePromptId?: string; // Links to a specific scene prompt ID
}

export interface Log {
  id: string;
  time: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  details: string;
}

interface AppState {
  _version: number;
  isHydrated: boolean;
  setHydrated: (hydrated: boolean) => void;
  assets: Asset[];
  favorites: Favorite[];
  favoritedAssetIds: string[];
  acts: Act[];
  logs: Log[];
  prompts: {
    systemA: string;
    fixedC: string;
    shortSplitPrompt: string;
    longSplitPrompt: string;
    actToShotsPrompt: string;
    globalSystemPrompt: string;
  };
  apiKeys: {
    globalApiKey: string;
    doubaoId: string;
    deepseekId: string;
    seedanceId: string;
    seedanceFastId: string;
    // Legacy support for older users, optional
    doubao?: string;
    deepseek?: string;
    seedanceKey?: string;
  };
  activeSeedanceModel: 'standard' | 'fast';
  setActiveSeedanceModel: (model: 'standard' | 'fast') => void;
  savedPrompts: { id: string; name: string; content: string; type: 'A' | 'C' }[];
  scenePrompts: ScenePromptTemplate[];
  setScenePrompts: (prompts: ScenePromptTemplate[]) => void;
  shortStoryText: string;
  setShortStoryText: (text: string) => void;
  longScriptText: string;
  setLongScriptText: (text: string) => void;
  addAsset: (asset: Asset) => void;
  updateAsset: (id: string, updates: Partial<Asset>) => void;
  removeAsset: (id: string) => void;
  toggleAssetFavorite: (id: string) => void;
  addFavorite: (fav: Favorite) => void;
  removeFavorite: (id: string) => void;
  setFavorites: (favs: Favorite[]) => void;
  setActs: (acts: Act[]) => void;
  updateAct: (id: string, updates: Partial<Act>) => void;
  updatePrompts: (prompts: Partial<AppState['prompts']>) => void;
  updateApiKeys: (keys: Partial<AppState['apiKeys']>) => void;
  reorderActs: (startIndex: number, endIndex: number) => void;
  reorderLinkedAssets: (actId: string, startIndex: number, endIndex: number) => void;
  removeShot: (actId: string, shotId: string) => void;
  addLog: (log: Omit<Log, 'id' | 'time'>) => void;
  clearLogs: () => void;
  addSavedPrompt: (prompt: Omit<AppState['savedPrompts'][0], 'id'>) => void;
  removeSavedPrompt: (id: string) => void;
  clearAllShots: () => void;
  clearStory: () => void;
}

const SHOT_PROMPT_BASE = `请将剧本拆解为带有精确时长标引（如00-02s）的分镜列表，详细描述每一镜的景别、运镜、视觉动作及台词，并重点突出画面的光影氛围感。`;

// 同步保存到物理磁盘的函数
const apiStorage = {
  getItem: async (name: string): Promise<string | null> => {
    try {
      const res = await fetch(`/api/config?name=${name}`);
      if (!res.ok) return null;
      const data = await res.json();
      return typeof data.value === 'string' ? data.value : null;
    } catch {
      return null;
    }
  },
  setItem: async (name: string, value: string): Promise<void> => {
    try {
      // 🛡️ Client Side Guard:
      // Don't save if the context says it hasn't hydrated yet (prevents overwriting valid DB with default state)
      // We parse the value to check for our internal flags
      const parsed = JSON.parse(value);
      if (parsed.state && parsed.state.isHydrated === false) {
        console.warn('[Store Guard] Prevented saving unhydrated state to API');
        return;
      }

      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, value })
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Server rejected save');
      }
    } catch (e) {
      console.error('Failed to save to local API config', e);
    }
  },
  removeItem: async (name: string): Promise<void> => {
    try {
      await fetch(`/api/config?name=${name}`, { method: 'DELETE' });
    } catch (e) {
      console.error('Failed to remove from local API config', e);
    }
  }
};

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      _version: 1,
      isHydrated: false,
      setHydrated: (val) => set({ isHydrated: val }),
      assets: [
        { id: 'asset-1', name: '冷酷男主参考', category: '男生', tags: ['黑发', '西装'], type: 'image', originalUrl: 'https://picsum.photos/seed/boy1/400/600' },
        { id: 'asset-2', name: '赛博朋克街道', category: '场景', tags: ['霓虹', '夜景'], type: 'image', originalUrl: 'https://picsum.photos/seed/scene1/800/400' },
      ],
      favorites: [],
      favoritedAssetIds: [],
      acts: [],
      logs: [],
      prompts: {
        systemA: '你是一名顶级短剧导演，审美高超，请你根据以下剧本内容拍摄一段真人短剧视频:场景:白天，室外，参考图1;女主参考图2，男主参考图3',
        fixedC: '电影级面光，光线追踪，人像面部聚焦，人物动作流畅',
        shortSplitPrompt: `${SHOT_PROMPT_BASE}\n\n请将以上要求应用于以下15秒内的小故事，并严格返回JSON数组格式：[{"title": "第一幕", "characters": ["提取出的人物1", "提取出的人物2"], "shots": [{"description": "镜头1描述..."}]}]`,
        longSplitPrompt: `你是一名资深短视频短剧导演。请对以下提供的剧本进行全局叙事流分析，将其拆解为多个 15秒/幕 的高频快节奏片段。
全局分析要求（核心）：
1. 打破段落限制：严禁按原文段落进行一对一分析。请将全文视为一个整体的信息流，根据戏剧冲突点和 15 秒的时长逻辑，自由地跨段落提取并重新组装内容。
2. 内容重组：确保每一幕的内容量都达到 15 秒的饱和度，如果一段内容不足 15 秒，必须从后文提取内容填补，直到该幕满负荷为止。
短剧节奏模型：
1. 环境/动作快剪（20%时长）：环境交代严禁超过 1.5 秒；纯动作描述（如走路、倒茶）严禁超过 2 秒。要求通过高频切镜（景别切换）来压缩视觉时长。
2. 台词推进（60%时长）：台词是核心。按正常语速 3-4 字/秒计算，确保每一幕都有实质性的对话或内心独白推进。
3. 情绪反应特写（20%时长）：给到人物神态、关键道具（如扳指、水洼）的特写，每个特写时长控制在 1 秒以内，用于强化冲突。
规则：
1. 严禁改写原文：直接提取原文进行组合。
2. 高密度拆分：每一幕 15 秒内必须包含“环境交代+连续动作+核心台词+情绪反转”，拒绝冗长的铺垫。
请严格返回JSON数组格式：[{"title": "第一幕", "originalText": "这一幕的剧情描述...", "characters": ["人物A", "人物B"]}]`,
        actToShotsPrompt: `${SHOT_PROMPT_BASE}\n\n请严格返回JSON数组格式，例如：[{"description": "镜头1描述..."}, {"description": "镜头2描述..."}]`,
        globalSystemPrompt: `你是一名顶级建模师，审美高超，并且明白时代风俗，引领女性当下审美，请你根据以下描述为我生成一份mj提示词。不需要任何解释、翻译和多余的话。`,
      },
      apiKeys: { 
        globalApiKey: '',
        doubaoId: 'ep-20260413173422-w4ggg', 
        deepseekId: 'ep-20260413173125-z5dcr', 
        seedanceId: 'ep-20260417124710-7fxlb',
        seedanceFastId: 'ep-20260416143747-ttzcw',
        doubao: '', // legacy
        deepseek: '', // legacy
        seedanceKey: '' // legacy
      },
      activeSeedanceModel: 'standard',
      savedPrompts: [],
      scenePrompts: [
        { id: 'default', name: '预设A1 (标准)', content: '你是一名顶级短剧导演，审美高超，请你根据以下剧本内容拍摄一段真人短剧视频:\n场景:白天，室外，参考图1\n【关联资产】' },
        { id: 'template2', name: '预设A2 (夜景)', content: '你是一名顶级短剧导演，审美高超，请你根据以下剧本内容拍摄一段真人短剧视频:\n场景:夜晚，室外，赛博朋克霓虹灯，参考图1\n【关联资产】' }
      ],
      shortStoryText: '',
      longScriptText: '',
      
      setScenePrompts: (prompts) => set({ scenePrompts: prompts }),
      setShortStoryText: (text) => set({ shortStoryText: text }),
      setLongScriptText: (text) => set({ longScriptText: text }),
      setActiveSeedanceModel: (model) => set({ activeSeedanceModel: model }),

      addAsset: (asset) => set((state) => ({ assets: [asset, ...state.assets] })),
      updateAsset: (id, updates) => set((state) => ({
        assets: state.assets.map(a => a.id === id ? { ...a, ...updates } : a)
      })),
      removeAsset: (id) => set((state) => ({ 
        assets: state.assets.filter(a => a.id !== id),
        favoritedAssetIds: state.favoritedAssetIds.filter(sid => sid !== id)
      })),
      toggleAssetFavorite: (id) => set((state) => ({
        favoritedAssetIds: state.favoritedAssetIds.includes(id) 
          ? state.favoritedAssetIds.filter(sid => sid !== id)
          : [...state.favoritedAssetIds, id]
      })),
      
      addFavorite: (fav) => set((state) => ({ favorites: [fav, ...state.favorites] })),
      removeFavorite: (id) => set((state) => ({ favorites: state.favorites.filter(f => f.id !== id) })),
      setFavorites: (favs) => set({ favorites: favs }),

      setActs: (acts) => set({ acts }),
      updateAct: (id, updates) => set((state) => ({
        acts: state.acts.map(a => a.id === id ? { 
          ...a, 
          duration: a.duration || 10, 
          resolution: a.resolution || '720p',
          ratio: a.ratio || '16:9',
          ...updates 
        } : a)
      })),
      
      updatePrompts: (prompts) => set((state) => ({ prompts: { ...state.prompts, ...prompts } })),
      updateApiKeys: (keys) => set((state) => ({ apiKeys: { ...state.apiKeys, ...keys } })),
      
      reorderActs: (startIndex, endIndex) => set((state) => {
        const result = Array.from(state.acts);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return { acts: result.map((a, i) => ({ ...a, index: i })) };
      }),

      reorderLinkedAssets: (actId, startIndex, endIndex) => set((state) => ({
        acts: state.acts.map(act => {
          if (act.id !== actId) return act;
          const result = Array.from(act.linkedAssets);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { ...act, linkedAssets: result };
        })
      })),

      removeShot: (actId, shotId) => set((state) => ({
        acts: state.acts.map(act => {
          if (act.id !== actId) return act;
          return { ...act, shots: act.shots.filter(s => s.id !== shotId) };
        })
      })),

      addLog: (log) => set((state) => ({
        logs: [{ ...log, id: Date.now().toString() + Math.random(), time: new Date().toLocaleTimeString() }, ...state.logs]
      })),
      clearLogs: () => set({ logs: [] }),

      addSavedPrompt: (prompt) => set((state) => ({
        savedPrompts: [{ ...prompt, id: Date.now().toString() }, ...state.savedPrompts]
      })),
      removeSavedPrompt: (id) => set((state) => ({
        savedPrompts: state.savedPrompts.filter(p => p.id !== id)
      })),

      clearAllShots: () => set((state) => ({
        acts: state.acts.map(act => ({ ...act, shots: [], shotsGenerated: false }))
      })),
      clearStory: () => set({ acts: [] }),
    }),
    {
      name: 'ai-short-drama-storage',
      storage: createJSONStorage(() => apiStorage),
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.setHydrated(true);
        }
      },
    }
  )
);