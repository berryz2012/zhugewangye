import { FaceDetector, FilesetResolver } from "@mediapipe/tasks-vision";

let faceDetector: FaceDetector | null = null;

export async function initFaceDetector() {
  if (faceDetector) return faceDetector;
  
  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
  );
  
  faceDetector = await FaceDetector.createFromOptions(vision, {
    baseOptions: {
      modelAssetPath: "https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite",
      delegate: "GPU"
    },
    runningMode: "IMAGE"
  });
  
  return faceDetector;
}

export async function processImage(file: File, detector: FaceDetector, options: { mode?: 'auto-split' | 'auto-single', color?: string } = {}): Promise<Blob> {
  const { mode = 'auto-split', color = "red" } = options;
  const headOnly = mode === 'auto-split';
  
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      try {
        const detections = detector.detect(img).detections;
        
        const canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Could not get canvas context");
        
        if (headOnly) {
          // Fill with Red
          ctx.fillStyle = "#FF0000";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          if (detections.length > 0) {
            // Find the largest face to determine scaling for the frame
            const primaryDetection = detections.reduce((prev, current) => {
              const prevArea = (prev.boundingBox?.width || 0) * (prev.boundingBox?.height || 0);
              const currArea = (current.boundingBox?.width || 0) * (current.boundingBox?.height || 0);
              return currArea > prevArea ? current : prev;
            });

            const pBox = primaryDetection.boundingBox;
            let scale = 1.0;
            let offsetX = 0;
            let offsetY = 0;

            if (pBox) {
              const faceArea = pBox.width * pBox.height;
              const canvasArea = canvas.width * canvas.height;
              const currentRatio = faceArea / canvasArea;
              const targetRatio = 0.2;

              // If face is too large (close-up), shrink it to fit ~20% area
              if (currentRatio > targetRatio) {
                scale = Math.sqrt(targetRatio / currentRatio);
                // Center the primary face on the canvas
                const pCenterX = pBox.originX + pBox.width / 2;
                const pCenterY = pBox.originY + pBox.height / 2;
                offsetX = (canvas.width / 2) - (pCenterX * scale);
                offsetY = (canvas.height * 0.45) - (pCenterY * scale); // Slightly higher than center
              }
            }

            // Draw each head with a tight oval mask using calculated scaling
            for (const detection of detections) {
              if (detection.boundingBox) {
                const { originX, originY, width, height } = detection.boundingBox;
                
                const centerX = (originX + width / 2) * scale + offsetX;
                const centerY = (originY + height / 2) * scale + offsetY;
                
                const radiusX = width * 0.7 * scale; 
                const radiusY = height * 0.9 * scale;
                
                ctx.save();
                ctx.beginPath();
                // Shift clip center slightly up to capture hair top
                ctx.ellipse(centerX, centerY - (height * 0.2 * scale), radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.clip();
                
                ctx.drawImage(img, offsetX, offsetY, img.width * scale, img.height * scale);
                ctx.restore();
              }
            }
          } else {
            // Circular center fallback
            ctx.save();
            ctx.beginPath();
            const boxSize = Math.min(img.width, img.height) * 0.35;
            ctx.arc(img.width / 2, img.height / 2, boxSize / 2, 0, Math.PI * 2);
            ctx.clip();
            ctx.drawImage(img, 0, 0);
            ctx.restore();
          }
        } else {
          // Single Mask: Draw original image then red-out face and shoulders
          ctx.drawImage(img, 0, 0);
          ctx.fillStyle = color === "white" || color === "black" ? "red" : color; // Default to red as per user request
          
          for (const detection of detections) {
            if (detection.boundingBox) {
              const { originX, originY, width, height } = detection.boundingBox;
              const centerX = originX + width / 2;
              
              // Cover Face
              const pX = width * 0.15;
              const pY = height * 0.15;
              ctx.fillRect(originX - pX, originY - pY, width + pX * 2, height + pY * 2);
              
              // Also cover shoulders area (roughly below the head)
              const shoulderWidth = width * 3.5;
              const shoulderHeight = height * 3;
              ctx.fillRect(centerX - shoulderWidth / 2, originY + height * 0.8, shoulderWidth, shoulderHeight);
            }
          }
          
          if (detections.length === 0) {
            // Fallback blocks for face and shoulders if no detection
            const blockWidth = img.width * 0.4;
            const blockHeight = img.height * 0.4;
            ctx.fillRect((img.width - blockWidth) / 2, (img.height * 0.3 - blockHeight / 2), blockWidth, blockHeight);
            ctx.fillRect(0, img.height * 0.6, img.width, img.height * 0.4);
          }
        }
        
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error("Failed to create blob"));
        }, file.type || "image/jpeg", 0.95);
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}
