
export interface SeedanceRequest {
  model: string;
  content: Array<{
    type: 'text' | 'image_url' | 'audio_url';
    text?: string;
    image_url?: { url: string };
    audio_url?: { url: string };
    role?: 'reference_image' | 'first_frame' | 'last_frame' | 'reference_audio';
  }>;
  duration?: number;
  resolution?: '480p' | '720p';
  ratio?: string;
}

export async function generateSeedanceVideo(apiKey: string, request: SeedanceRequest) {
  try {
    const response = await fetch('/api/seedance', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        apiKey,
        payload: {
          model: request.model,
          content: request.content,
          duration: request.duration || 10,
          resolution: request.resolution || '720p',
          ratio: request.ratio || '16:9',
          generate_audio: true,
          watermark: true
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMessage = errorData.error || errorData.message || `API Request failed with status ${response.status}`;
      throw new Error(errorMessage);
    }

    const data = await response.json();
    
    // Favor taskId (async) if available, as most jobs are long-running
    if (data.id) {
      return { taskId: data.id };
    } else if (data.video_url) {
      return { videoUrl: data.video_url };
    }
    
    throw new Error('Invalid response from Seedance API');
  } catch (error) {
    console.error('Seedance API Error:', error);
    throw error;
  }
}

export async function pollTaskStatus(apiKey: string, taskId: string, checkCancel?: () => boolean): Promise<string> {
  const POLLING_INTERVAL = 5000;
  
  while (true) {
    if (checkCancel && checkCancel()) {
      throw new Error('Task cancelled by user');
    }

    await new Promise(resolve => setTimeout(resolve, POLLING_INTERVAL));
    
    try {
      const response = await fetch(`/api/seedance/task/${taskId}`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`
        }
      });
      
      if (!response.ok) {
        const errorText = await response.text().catch(() => 'No error body');
        console.error(`[Task ${taskId} Polling Error - Status ${response.status}]:`, errorText);
        
        if (response.status === 404 || response.status === 400) {
           throw new Error(`Fatal API error: ${response.status}. Body: ${errorText.substring(0, 500)}`);
        }
        continue;
      }

      const data = await response.json();
      
      console.log(`[Task ${taskId} Polling Status]:`, data);

      if (data.status === 'succeeded') {
        const videoUrl = data.video_url || 
                        (data.content && data.content.video_url) ||
                        (data.result && data.result.video_url) || 
                        (data.task_result && data.task_result.video_url);
                        
        if (videoUrl) return videoUrl;
        throw new Error('Task succeeded but no video URL found in response');
      } else if (data.status === 'failed' || data.status === 'expired' || data.status === 'cancelled') {
        const errorMsg = data.error || 
                        (data.content && data.content.error) ||
                        (data.result && data.result.error) || 
                        `Video generation task ${data.status}`;
        throw new Error(typeof errorMsg === 'string' ? errorMsg : JSON.stringify(errorMsg));
      }
      
      console.log(`[Polling] Task ${taskId} status: ${data.status}`);
    } catch (err: any) {
      if (err.message.includes('task failed') || err.message.includes('No video URL') || err.message.includes('Fatal API') || err.message.includes('Task cancelled') || err.message.includes('expired') || err.message.includes('cancelled')) {
        throw err;
      }
      console.warn(`[Polling Error] ${err.message}`);
    }
  }
}
