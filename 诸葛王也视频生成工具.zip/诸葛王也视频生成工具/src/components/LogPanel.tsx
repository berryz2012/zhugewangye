import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { Terminal, ChevronUp, ChevronDown, Trash2, X, Info, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function LogPanel() {
  const { logs, clearLogs } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Removed auto-hide so the user always sees where it is
  // if (logs.length === 0 && !isOpen) return null;

  return (
    <div className={`fixed bottom-4 left-4 z-50 transition-all duration-300 ease-in-out ${isOpen ? 'w-[450px]' : 'w-auto'}`}>
      {/* Toggle Button */}
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-zinc-900 border border-zinc-800 text-zinc-400 px-3 py-2 rounded-lg flex items-center gap-2 hover:bg-zinc-800 hover:text-white transition-all shadow-xl"
        >
          <Terminal size={16} />
          <span className="text-xs font-medium">运行日志 ({logs.length})</span>
          {logs.some(l => l.type === 'error') && (
            <span className="flex h-2 w-2 rounded-full bg-red-500 animate-pulse" />
          )}
        </button>
      )}

      {/* Expanded Panel */}
      {isOpen && (
        <div className="bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl flex flex-col h-[400px] overflow-hidden">
          {/* Header */}
          <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
            <div className="flex items-center gap-2">
              <Terminal size={16} className="text-indigo-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">系统运行日志</span>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={clearLogs}
                className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-500/10 rounded transition-all"
                title="清空日志"
              >
                <Trash2 size={14} />
              </button>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-800 rounded transition-all"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Log List */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 custom-scrollbar"
          >
            {logs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-zinc-600 gap-2 italic text-xs">
                <Info size={24} className="opacity-20" />
                暂无运行日志
              </div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="flex flex-col gap-1 border-b border-zinc-900 pb-3 last:border-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {log.type === 'error' && <AlertCircle size={14} className="text-red-500 shrink-0" />}
                      {log.type === 'success' && <CheckCircle2 size={14} className="text-green-500 shrink-0" />}
                      {log.type === 'info' && <Info size={14} className="text-blue-500 shrink-0" />}
                      <span className={`text-xs font-bold ${
                        log.type === 'error' ? 'text-red-400' : 
                        log.type === 'success' ? 'text-green-400' : 
                        'text-blue-400'
                      }`}>
                        {log.title}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-600 shrink-0">{log.time}</span>
                  </div>
                  <div className="pl-5">
                    <pre className="text-[10px] font-mono text-zinc-500 whitespace-pre-wrap break-all leading-relaxed">
                      {log.details}
                    </pre>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
