import { useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { pollTaskStatus } from '@/lib/seedanceApi';

export default function TaskPoller() {
  const { acts, updateAct, addLog, apiKeys } = useStore();
  const pollingTasks = useRef<Set<string>>(new Set());

  useEffect(() => {
    acts.forEach(act => {
      if (act.status === 'generating' && act.taskId && !pollingTasks.current.has(act.taskId)) {
        // Start polling for this act
        const taskId = act.taskId;
        const actId = act.id;
        pollingTasks.current.add(taskId);
        
        console.log(`Resuming polling for task ${taskId}...`);
        
        // Provide a mechanism to abort polling if the act's status changes or taskID changes
        const checkCancel = () => {
          const currentAct = useStore.getState().acts.find(a => a.id === actId);
          if (!currentAct) return true;
          if (currentAct.status !== 'generating') return true;
          if (currentAct.taskId !== taskId) return true;
          return false;
        };

        pollTaskStatus(apiKeys.globalApiKey || apiKeys.seedanceKey || '', taskId, checkCancel)
          .then(videoUrl => {
            // CRITICAL: Verify if this task is still the current active task for this act
            const freshAct = useStore.getState().acts.find(a => a.id === actId);
            if (!freshAct || freshAct.taskId !== taskId) {
              console.log(`Ignoring results for obsolete task ${taskId}`);
              return;
            }

            const h = [...(freshAct.videoHistory || [])];
            if (freshAct.videoUrl && !h.includes(freshAct.videoUrl)) {
              h.push(freshAct.videoUrl);
            }
            h.push(videoUrl);
            
            updateAct(actId, { 
              status: 'done', 
              videoUrl: videoUrl,
              videoHistory: [...new Set(h)]
            });
            addLog({ 
              type: 'success', 
              title: `视频生成成功 (任务反馈) - ${freshAct.title}`, 
              details: `Video URL: ${videoUrl}\nTask ID: ${taskId}` 
            });
          })
          .catch(err => {
            // Check if this error belongs to the current task
            const freshAct = useStore.getState().acts.find(a => a.id === actId);
            if (!freshAct || freshAct.taskId !== taskId) return;
            
            // If the user manually aborted it, the status is no longer generating, so we shouldn't mark it as an error
            if (freshAct.status !== 'generating') return;

            updateAct(actId, { status: 'error', errorReason: '生成超时或任务中断' });
            addLog({ 
              type: 'error', 
              title: `生成失败 - ${freshAct?.title || actId}`, 
              details: `Error: ${err.message}\nTask ID: ${taskId}` 
            });
          })
          .finally(() => {
            pollingTasks.current.delete(taskId);
          });
      }
    });
  }, [acts, updateAct, addLog, apiKeys.globalApiKey, apiKeys.seedanceKey]);

  return null;
}
