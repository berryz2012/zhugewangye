import React from 'react';
import { useStore } from '@/store/useStore';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Download, Film, GripVertical, PlayCircle, ChevronDown, ChevronUp, X, Maximize2, Trash2, AlertCircle } from 'lucide-react';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';

export default function VideoGallery() {
  const { acts, reorderActs, updateAct } = useStore();
  const [expandedActs, setExpandedActs] = React.useState<Record<string, boolean>>({});
  const [enlargedVideo, setEnlargedVideo] = React.useState<{actId: string, url: string} | null>(null);
  
  const completedActs = acts.filter(a => a.status === 'done' && a.videoUrl);

  const toggleExpand = (id: string) => {
    setExpandedActs(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    reorderActs(result.source.index, result.destination.index);
  };

  const handleBatchDownload = async () => {
    if (completedActs.length === 0) return;
    const zip = new JSZip();
    
    // In a real app, you'd fetch the actual video blobs. 
    // Here we just mock it by creating empty blobs or fetching the placeholder.
    completedActs.forEach((act, idx) => {
      zip.file(`act_${idx + 1}_${act.title}.mp4`, "mock video content");
    });
    
    const content = await zip.generateAsync({ type: 'blob' });
    saveAs(content, 'drama_videos.zip');
  };

  const handleDeleteSingleVideo = (actId: string, url: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    const newHistory = (act.videoHistory || [act.videoUrl!]).filter(u => u !== url);
    if (newHistory.length === 0) {
      updateAct(actId, { status: 'idle', videoUrl: undefined, videoHistory: [] });
    } else {
      updateAct(actId, { 
        videoHistory: newHistory,
        videoUrl: act.videoUrl === url ? newHistory[newHistory.length - 1] : act.videoUrl
      });
    }
    setEnlargedVideo(null);
  };

  const handleClearActVideos = (actId: string) => {
    if(confirm('确定要清除这一幕的所有视频版本吗？')) {
      updateAct(actId, { status: 'idle', videoUrl: undefined, videoHistory: [] });
    }
  };

  const handleClearAllVideos = () => {
    if(confirm('确定要清空所有已生成的视频吗？')) {
      acts.forEach(act => {
        updateAct(act.id, { status: 'idle', videoUrl: undefined, videoHistory: [] });
      });
    }
  };

  return (
    <div className="h-full flex flex-col gap-6 text-zinc-100">
      {/* Header */}
      <div className="flex items-center justify-between bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 shrink-0">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Film className="text-indigo-400" />
            视频展示区
          </h2>
          <p className="text-sm text-zinc-400 mt-1">
            拖拽调整视频顺序，鼠标悬浮即可播放预览。支持单段或批量下载。
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleClearAllVideos}
            disabled={completedActs.length === 0}
            className="px-4 py-2 bg-red-600/20 text-red-400 border border-red-500/30 rounded-lg text-sm font-medium hover:bg-red-600/40 hover:text-white hover:border-red-500/50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            清空所有视频
          </button>
          <button
            onClick={handleBatchDownload}
            disabled={completedActs.length === 0}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2 shadow-lg shadow-indigo-500/20"
          >
            <Download className="w-4 h-4" />
            批量下载全部 ({completedActs.length})
          </button>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pb-8">
        {acts.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 gap-3 border-2 border-dashed border-zinc-800/50 rounded-2xl m-2">
            <Film size={48} className="opacity-20" />
            <p>暂无视频，请前往“视频设置”生成</p>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="gallery">
              {(provided) => (
                <div 
                  {...provided.droppableProps} 
                  ref={provided.innerRef}
                  className="flex flex-col gap-4 p-2 max-w-4xl mx-auto"
                >
                  {acts.map((act, index) => (
                    // @ts-ignore
                    <Draggable key={act.id} draggableId={act.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`bg-zinc-900/60 border rounded-2xl p-4 flex gap-6 items-center transition-all ${
                            snapshot.isDragging ? 'border-indigo-500 shadow-2xl shadow-indigo-500/20 scale-[1.02] z-50 bg-zinc-900' : 'border-zinc-800 hover:border-zinc-700'
                          }`}
                        >
                          {/* Drag Handle */}
                          <div 
                            {...provided.dragHandleProps}
                            className="text-zinc-600 hover:text-zinc-300 cursor-grab active:cursor-grabbing p-2"
                          >
                            <GripVertical size={20} />
                          </div>

                          {/* Video Previews */}
                          <div className="flex gap-3 overflow-x-auto custom-scrollbar shrink-0 max-w-[500px] pb-2">
                            {act.status === 'generating' || act.status === 'queued' ? (
                              <div className="w-48 h-28 shrink-0 bg-black rounded-xl border border-zinc-800 relative flex flex-col items-center justify-center text-zinc-600 gap-2">
                                <span className={`text-xs ${act.status === 'queued' ? 'text-yellow-400' : 'text-indigo-400 animate-pulse'}`}>
                                  {act.status === 'queued' ? '排队中 (等待生成)...' : '生成中...'}
                                </span>
                                <div className="absolute top-2 left-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                                  幕 {index + 1}
                                </div>
                              </div>
                            ) : (act.videoHistory && act.videoHistory.length > 0) || act.videoUrl ? (
                              (act.videoHistory?.length ? act.videoHistory : [act.videoUrl!]).map((vUrl, vIdx, arr) => (
                                <div 
                                  key={vIdx}
                                  className="w-48 h-28 shrink-0 bg-black rounded-xl overflow-hidden relative group border border-zinc-800 cursor-zoom-in"
                                  onClick={() => setEnlargedVideo({actId: act.id, url: vUrl})}
                                >
                                  <video 
                                    src={vUrl} 
                                    muted 
                                    loop 
                                    onMouseEnter={(e) => e.currentTarget.play()} 
                                    onMouseLeave={(e) => { e.currentTarget.pause(); e.currentTarget.currentTime = 0; }}
                                    className="w-full h-full object-contain bg-zinc-950"
                                  />
                                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                                    <Maximize2 size={32} className="text-white/80" />
                                  </div>
                                  <div className="absolute top-2 left-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                                    幕 {index + 1} {arr.length > 1 && `(版${vIdx + 1})`}
                                  </div>
                                  {vUrl === act.videoUrl ? (
                                    <div className="absolute bottom-2 left-2 bg-indigo-600 border border-indigo-400 text-white text-[9px] px-1.5 py-0.5 rounded font-bold shadow-sm">
                                      主序列
                                    </div>
                                  ) : (
                                    <button 
                                      className="absolute bottom-2 left-2 opacity-0 group-hover:opacity-100 bg-zinc-800/90 hover:bg-indigo-600 text-white text-[9px] px-2 py-1 rounded font-bold transition-all shadow-lg"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        updateAct(act.id, { videoUrl: vUrl });
                                      }}
                                    >
                                      设为主序列
                                    </button>
                                  )}
                                </div>
                              ))
                            ) : (
                              <div className="w-48 h-28 shrink-0 bg-black rounded-xl border border-zinc-800 relative flex flex-col items-center justify-center text-zinc-600 gap-2">
                                <span className="text-xs">未生成</span>
                                <div className="absolute top-2 left-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                                  幕 {index + 1}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0 flex flex-col gap-2">
                            <p className="text-sm font-medium text-zinc-200">{act.title}</p>
                            <div 
                              className="cursor-pointer group/text"
                              onClick={() => toggleExpand(act.id)}
                            >
                              <p className={`text-xs text-zinc-400 leading-relaxed transition-all ${expandedActs[act.id] ? '' : 'line-clamp-2'}`}>
                                {act.shots.map(s => s.description).join(' ')}
                              </p>
                              <div className="flex items-center gap-1 mt-1 text-[10px] text-zinc-500 group-hover/text:text-indigo-400 transition-colors">
                                {expandedActs[act.id] ? (
                                  <><ChevronUp size={10} /> 点击收起</>
                                ) : (
                                  <><ChevronDown size={10} /> 点击展开全部内容</>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="shrink-0 flex items-center gap-2">
                            {act.status === 'done' ? (
                              <div className="flex items-center gap-2">
                                <button 
                                  onClick={() => handleClearActVideos(act.id)}
                                  className="p-2.5 bg-zinc-800 hover:bg-red-600/80 text-zinc-400 hover:text-white rounded-xl transition-colors border border-transparent hover:border-red-500/50"
                                  title="清除这一幕的视频"
                                >
                                  <Trash2 size={18} />
                                </button>
                                <button 
                                  onClick={() => saveAs(act.videoUrl!, `act_${index + 1}.mp4`)}
                                  className="p-2.5 bg-zinc-800 hover:bg-indigo-600 text-zinc-300 hover:text-white rounded-xl transition-colors"
                                  title="下载单段主序列"
                                >
                                  <Download size={18} />
                                </button>
                              </div>
                            ) : act.status === 'error' ? (
                              <div className="bg-red-500/10 text-red-500 border border-red-500/20 px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
                                <AlertCircle size={14} /> 生成失败
                              </div>
                            ) : (act.status === 'generating' || act.status === 'queued') ? (
                              <div className="bg-zinc-800/50 text-zinc-500 border border-zinc-800 px-3 py-2 rounded-xl text-[10px] font-bold uppercase animate-pulse">
                                {act.status === 'queued' ? '排队中...' : '生成中...'}
                              </div>
                            ) : null}
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>

      {/* Video Enlargement Modal */}
      {enlargedVideo && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-xl p-4 lg:p-12"
          onClick={() => setEnlargedVideo(null)}
        >
          <div className="relative w-full h-full max-w-7xl flex flex-col items-center justify-center" onClick={e => e.stopPropagation()}>
            <video 
              src={enlargedVideo.url} 
              controls 
              autoPlay 
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
            />
            {/* Top Right Controls Wrapper */}
            <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 p-1.5 rounded-full border border-white/10 backdrop-blur-md">
              <button 
                onClick={() => handleDeleteSingleVideo(enlargedVideo.actId, enlargedVideo.url)}
                className="p-2.5 hover:bg-red-500/80 text-zinc-400 hover:text-white rounded-full transition-all"
                title="删除当前版本"
              >
                <Trash2 size={20} />
              </button>
              <div className="w-[1px] h-6 bg-white/20"></div>
              <button 
                onClick={() => setEnlargedVideo(null)}
                className="p-2.5 hover:bg-white/20 text-zinc-300 hover:text-white rounded-full transition-all"
                title="关闭预览"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
