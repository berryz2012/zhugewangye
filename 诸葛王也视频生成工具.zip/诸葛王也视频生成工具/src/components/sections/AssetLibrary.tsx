import React, { useState, useRef, useEffect } from 'react';
import { Plus, Image as ImageIcon, Tag, UploadCloud, Loader2, X, Eraser, Check, Wand2, MousePointer2, Search, SplitSquareHorizontal, Square, Trash2, Star, Layers } from 'lucide-react';
import { initFaceDetector, processImage } from '@/lib/faceDetection';
import type { FaceDetector } from '@mediapipe/tasks-vision';
import { useStore, Category, Asset } from '@/store/useStore';

const CATEGORIES: (Category | '全部' | '收藏')[] = ['全部', '收藏', '男生', '女生', '服装', '场景', '道具', '音频', '其他'];

export default function AssetLibrary() {
  const { assets, addAsset, updateAsset, removeAsset, favoritedAssetIds, toggleAssetFavorite } = useStore();
  const [activeCategory, setActiveCategory] = useState<Category | '全部' | '收藏'>('全部');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [isMergeModalOpen, setIsMergeModalOpen] = useState(false);
  const [previewAsset, setPreviewAsset] = useState<Asset | null>(null);
  const [selectedForMerge, setSelectedForMerge] = useState<string[]>([]);
  
  const [isInitializing, setIsInitializing] = useState(false);
  const [detector, setDetector] = useState<FaceDetector | null>(null);
  
  // Form State
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Category>('男生');
  const [tagsInput, setTagsInput] = useState('');
  const [processMode, setProcessMode] = useState<'none' | 'auto-split' | 'auto-single' | 'manual'>('none');
  const [isProcessing, setIsProcessing] = useState(false);

  // Canvas State for Manual Drawing
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    if (isAddModalOpen && !detector) {
      setIsInitializing(true);
      initFaceDetector().then(d => {
        setDetector(d);
        setIsInitializing(false);
      }).catch(err => {
        console.error("Failed to init detector", err);
        setIsInitializing(false);
      });
    }
  }, [isAddModalOpen, detector]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files) as File[];
      
      // If single file, use the existing single-file flow (with editor)
      if (files.length === 1) {
        const selectedFile = files[0];
        setFile(selectedFile);
        setPreviewUrl(URL.createObjectURL(selectedFile));
        setProcessedUrl(null);
        setProcessMode('none');
        
        let targetCategory = activeCategory === '全部' ? '其他' : activeCategory as Category;
        if (selectedFile.type.startsWith('audio/')) {
          targetCategory = '音频';
        }
        setCategory(targetCategory);

        if (targetCategory === '服装') {
          setName('');
        } else {
          setName(selectedFile.name.split('.')[0]);
        }
        
        if (canvasRef.current) {
          const ctx = canvasRef.current.getContext('2d');
          ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }
      } 
      // If multiple files, use batch upload flow
      else {
        handleBatchUpload(files);
      }
    }
  };

  const uploadLocal = async (blob: Blob, filename: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64 = reader.result as string;
          const res = await fetch('/api/upload-local', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mediaBase64: base64, filename })
          });
          const data = await res.json();
          if (data.url) resolve(data.url);
          else reject(new Error(data.error || 'Upload failed'));
        } catch(e) { reject(e); }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const handleBatchUpload = async (files: File[]) => {
    setIsProcessing(true);
    try {
      let clothingCounterMale = assets.filter(a => a.name.startsWith("男主服装")).length;
      let clothingCounterFemale = assets.filter(a => a.name.startsWith("女主服装")).length;

      for (const file of files) {
        const url = await uploadLocal(file, file.name);
        let cat: Category = '其他';
        
        if (file.type.startsWith('audio/')) {
          cat = '音频';
        } else if (activeCategory !== '全部' && activeCategory !== '收藏') {
          cat = activeCategory as Category;
        }

        let assetName = file.name.split('.')[0];
        if (cat === '服装') {
          // Alternative logic: guess if it's male or female, otherwise just default to 女主服装
          clothingCounterFemale++;
          assetName = `女主服装${clothingCounterFemale > 1 ? clothingCounterFemale : ''}`;
        }

        const newAsset: Asset = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          name: assetName,
          category: cat,
          tags: [],
          type: file.type.startsWith('audio/') ? 'audio' : 'image',
          originalUrl: url,
          processedUrl: null
        };
        addAsset(newAsset);
      }
      setIsAddModalOpen(false);
    } catch (err) {
      console.error("Batch upload failed", err);
      alert("批量上传部分失败");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAutoProcess = async (mode: 'auto-split' | 'auto-single') => {
    if (!file || !detector) return;
    setIsProcessing(true);
    setProcessMode(mode);
    try {
      const blob = await processImage(file, detector, { mode, color: 'red' });
      setProcessedUrl(URL.createObjectURL(blob));
    } catch (err) {
      console.error("Auto process failed", err);
      alert("自动处理失败，请尝试手动涂抹。");
      setProcessMode('none');
    } finally {
      setIsProcessing(false);
    }
  };

  const setupCanvas = () => {
    if (processMode === 'manual' && imageRef.current && canvasRef.current) {
      const img = imageRef.current;
      const canvas = canvasRef.current;
      if (canvas.width !== img.naturalWidth) {
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
      }
    }
  };

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (processMode !== 'manual') return;
    setupCanvas(); // Force canvas to match natural naturalWidth exactly
    
    const coords = getCoordinates(e);
    if (!coords) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;
    
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    setIsDrawing(true);
    
    // Draw immediately so single clicks register as dots
    ctx.lineTo(coords.x, coords.y);
    ctx.strokeStyle = '#000000'; // Pure black for masking
    ctx.lineWidth = Math.max(canvas.width * 0.05, 20); // Scale pen according to image size
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || processMode !== 'manual') return;
    e.preventDefault(); // Prevent accidental scroll on mobile
    const coords = getCoordinates(e);
    if (!coords) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    ctx.lineTo(coords.x, coords.y);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = Math.max(canvas.width * 0.05, 20);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => setIsDrawing(false);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx && canvas) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const handleSaveAsset = async () => {
    if (!file || !previewUrl) return;
    setIsProcessing(true);

    try {
      let finalOriginalUrl = previewUrl;
      let finalProcessedUrl = processedUrl;

      // Upload original file to local server
      if (previewUrl.startsWith('blob:')) {
        finalOriginalUrl = await uploadLocal(file, file.name);
      }

      // If manual drawing is used, generated it here
      if (processMode === 'manual' && canvasRef.current) {
        const compositeCanvas = document.createElement('canvas');
        const img = new Image();
        
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
          img.src = previewUrl;
        });

        // Set strictly to the img's natural intrinsic resolution
        compositeCanvas.width = img.naturalWidth;
        compositeCanvas.height = img.naturalHeight;
        const ctx = compositeCanvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, compositeCanvas.width, compositeCanvas.height);
          // Scale the drawing overlay exactly to match the full image resolution
          ctx.drawImage(canvasRef.current, 0, 0, compositeCanvas.width, compositeCanvas.height);
          
          const manualBlob = await new Promise<Blob | null>(res => compositeCanvas.toBlob(res, 'image/jpeg', 0.95));
          if (manualBlob) {
            finalProcessedUrl = await uploadLocal(manualBlob, `manual_${file.name}`);
          }
        }
      } else if (processMode !== 'none' && processedUrl && processedUrl.startsWith('blob:')) {
        // If it was auto-processed, we fetch the blob and persist it
        const res = await fetch(processedUrl);
        const processedBlob = await res.blob();
        finalProcessedUrl = await uploadLocal(processedBlob, `processed_${file.name}`);
      }

      const newAsset: Asset = {
        id: Date.now().toString(),
        name: name || '未命名资产',
        category,
        tags: tagsInput.split(/[,，]/).map(t => t.trim()).filter(Boolean),
        type: file.type.startsWith('audio/') ? 'audio' : 'image',
        originalUrl: finalOriginalUrl,
        processedUrl: processMode !== 'none' ? finalProcessedUrl : null
      };

      addAsset(newAsset);
      closeModal();
    } catch (err) {
      console.error("Failed to save asset", err);
      alert("保存失败，请重试。");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMergeImages = async () => {
    if (selectedForMerge.length < 2) return alert('请至少选择两张图片进行合并');
    setIsProcessing(true);
    try {
      const imgs = await Promise.all(selectedForMerge.map(id => {
        const asset = assets.find(a => a.id === id);
        return new Promise<HTMLImageElement>((resolve, reject) => {
          if (!asset) return reject('Asset not found');
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = asset.processedUrl || asset.originalUrl;
        });
      }));

      const canvas = document.createElement('canvas');
      const totalWidth = imgs.reduce((sum, img) => sum + img.width, 0);
      const maxHeight = Math.max(...imgs.map(img => img.height));
      
      canvas.width = totalWidth;
      canvas.height = maxHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('No context');

      let currentX = 0;
      imgs.forEach(img => {
        ctx.drawImage(img, currentX, 0);
        currentX += img.width;
      });

      const blob = await new Promise<Blob | null>(res => canvas.toBlob(res, 'image/jpeg', 0.95));
      if (!blob) throw new Error('Blob creation failed');
      const mergedUrl = await uploadLocal(blob, `merge_${Date.now()}.jpg`);
      
      const newAsset: Asset = {
        id: Date.now().toString(),
        name: '合并服装图片',
        category: '服装',
        tags: ['合并', '服装'],
        type: 'image',
        originalUrl: mergedUrl,
      };

      addAsset(newAsset);
      setIsMergeModalOpen(false);
      setSelectedForMerge([]);
    } catch (error) {
      console.error("Error merging images:", error);
      alert("合并失败，请重试");
    } finally {
      setIsProcessing(false);
    }
  };

  const closeModal = () => {
    setIsAddModalOpen(false);
    setFile(null);
    setPreviewUrl(null);
    setProcessedUrl(null);
    setName('');
    setTagsInput('');
    setProcessMode('none');
  };

  const handleUpdateAsset = () => {
    if (!editingAsset) return;
    updateAsset(editingAsset.id, {
      name,
      category,
      tags: tagsInput.split(/[,，]/).map(t => t.trim()).filter(Boolean)
    });
    setIsEditModalOpen(false);
    setEditingAsset(null);
  };

  const openEditModal = (asset: Asset) => {
    setEditingAsset(asset);
    setName(asset.name);
    setCategory(asset.category);
    setTagsInput(asset.tags.join(', '));
    setIsEditModalOpen(true);
  };

  const filteredAssets = assets.filter(a => 
    (activeCategory === '全部' || (activeCategory === '收藏' && favoritedAssetIds.includes(a.id)) || a.category === activeCategory) && 
    (a.name.includes(searchQuery) || a.tags.some(t => t.includes(searchQuery)))
  ).sort((a, b) => {
    const aFav = favoritedAssetIds.includes(a.id) ? 1 : 0;
    const bFav = favoritedAssetIds.includes(b.id) ? 1 : 0;
    return bFav - aFav; // favorited items come first
  });

  return (
    <div className="h-full flex flex-col gap-6 text-zinc-100">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">资产库</h2>
          <p className="text-sm text-zinc-400 mt-1">管理人物、场景、道具等素材，支持面部防检测涂黑处理。</p>
        </div>
        <div className="flex items-center gap-3">
          {activeCategory === '服装' && (
            <button
              onClick={() => setIsMergeModalOpen(true)}
              className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all border border-zinc-700 whitespace-nowrap"
            >
              <Layers size={18} />
              合并服装图片
            </button>
          )}
          <div className="text-sm text-zinc-400 bg-zinc-900/50 px-3 py-2 rounded-xl border border-zinc-800 flex items-center gap-2">
            <Star size={14} className="text-yellow-500" /> 已收藏 <span className="text-yellow-500 font-bold">{favoritedAssetIds.length}</span> 项
          </div>
          <button
            onClick={() => {
              setCategory(activeCategory);
              setIsAddModalOpen(true);
            }}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-500/20 whitespace-nowrap"
          >
            <Plus size={18} />
            添加新资产
          </button>
        </div>
      </div>

      {/* Categories & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0 bg-zinc-900/50 p-2 rounded-2xl border border-zinc-800/80">
        <div className="flex overflow-x-auto custom-scrollbar gap-1 p-1">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeCategory === cat 
                  ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50 border border-transparent'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="relative px-2 pb-2 sm:p-0 sm:pr-2">
          <Search className="absolute left-5 sm:left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            placeholder="搜索名称或标签..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full sm:w-64 bg-zinc-950 border border-zinc-800 rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-zinc-200 placeholder:text-zinc-600"
          />
        </div>
      </div>

      {/* Asset Grid */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pb-8">
        {filteredAssets.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 gap-3 border-2 border-dashed border-zinc-800/50 rounded-2xl m-2">
            <ImageIcon size={48} className="opacity-20" />
            <p>该分类下暂无资产</p>
            <button 
              onClick={() => {
                setCategory(activeCategory);
                setIsAddModalOpen(true);
              }} 
              className="text-indigo-400 hover:text-indigo-300 text-sm font-medium mt-2"
            >
              立即添加
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-2">
            {filteredAssets.map(asset => {
              const isFavorited = favoritedAssetIds.includes(asset.id);
              return (
                <div 
                  key={asset.id} 
                  className={`bg-zinc-900/60 rounded-2xl overflow-hidden transition-all group flex flex-col relative border-2 ${
                    isFavorited ? 'border-yellow-500/50 shadow-[0_0_15px_rgba(234,179,8,0.1)]' : 'border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  {/* Favorite Indicator */}
                  <button 
                    onClick={(e) => { e.stopPropagation(); toggleAssetFavorite(asset.id); }}
                    className={`absolute top-3 right-3 z-10 rounded-full p-1.5 transition-all backdrop-blur-md ${isFavorited ? 'bg-yellow-500 text-white scale-100' : 'bg-black/50 text-zinc-400 border border-white/20 scale-90 group-hover:scale-100 hover:text-yellow-500'}`}
                    title={isFavorited ? "取消收藏" : "加入收藏"}
                  >
                    <Star size={14} className={isFavorited ? "fill-current" : ""} />
                  </button>
                  
                  {/* Image/Audio Display */}
                  <div 
                    className="flex aspect-[3/4] bg-zinc-950 overflow-hidden relative cursor-pointer"
                    onClick={() => asset.type === 'image' && setPreviewAsset(asset)}
                  >
                    {asset.type === 'audio' ? (
                      <div className="w-full h-full flex items-center justify-center bg-zinc-900 p-4">
                        <audio src={asset.originalUrl} controls className="w-full" />
                      </div>
                    ) : (
                      <>
                        <div className={`${asset.processedUrl ? 'w-1/2' : 'w-full'} h-full relative bg-zinc-900/50`}>
                          <img src={asset.originalUrl} className="w-full h-full object-contain" alt="原图" />
                          {asset.processedUrl && <div className="absolute bottom-1 left-1 bg-black/70 text-[10px] px-1.5 py-0.5 rounded text-zinc-300">原图</div>}
                        </div>
                        {asset.processedUrl && (
                          <div className="w-1/2 h-full border-l border-zinc-800 relative bg-zinc-900/50">
                            <img src={asset.processedUrl} className="w-full h-full object-contain" alt="处理后" />
                            <div className="absolute bottom-1 right-1 bg-indigo-500/80 text-[10px] px-1.5 py-0.5 rounded text-white">处理后</div>
                          </div>
                        )}
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <Search size={24} className="text-white/70" />
                        </div>
                      </>
                    )}
                  </div>

                  <div className="p-4 flex flex-col gap-2 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-medium text-sm text-zinc-200 truncate" title={asset.name}>{asset.name}</h3>
                      <div className="flex items-center gap-1 shrink-0">
                        <button 
                          onClick={(e) => { e.stopPropagation(); openEditModal(asset); }}
                          className="text-zinc-500 hover:text-indigo-400 transition-colors"
                        >
                          <Wand2 size={14} />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); removeAsset(asset.id); }}
                          className="text-zinc-500 hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-auto">
                      {asset.tags.map((tag, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-zinc-800 text-zinc-400 text-[10px] rounded-md border border-zinc-700/50">
                          {tag}
                        </span>
                      ))}
                      {asset.tags.length === 0 && <span className="text-[10px] text-zinc-600">无标签</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Merge Modal */}
      {isMergeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl w-full max-w-4xl h-[80vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50 shrink-0">
              <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
                <Layers size={18} className="text-indigo-400" /> 合并服装图片
              </h2>
              <button onClick={() => { setIsMergeModalOpen(false); setSelectedForMerge([]); }} className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <p className="text-sm text-zinc-400 mb-4">请选择要合并的服装图片（例如正面和背面），合并后将生成一张左右拼接的新图片。</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {assets.filter(a => a.category === '服装' && a.type === 'image').map(asset => (
                  <div 
                    key={asset.id} 
                    onClick={() => {
                      if (selectedForMerge.includes(asset.id)) {
                        setSelectedForMerge(selectedForMerge.filter(id => id !== asset.id));
                      } else {
                        setSelectedForMerge([...selectedForMerge, asset.id]);
                      }
                    }}
                    className={`relative aspect-[3/4] rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                      selectedForMerge.includes(asset.id) ? 'border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.3)]' : 'border-transparent hover:border-zinc-600'
                    }`}
                  >
                    <img src={asset.processedUrl || asset.originalUrl} alt={asset.name} className="w-full h-full object-cover" />
                    {selectedForMerge.includes(asset.id) && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-indigo-500 rounded-full flex items-center justify-center text-white shadow-lg">
                        <Check size={14} />
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3 pt-8">
                      <p className="text-xs font-medium text-white truncate">{asset.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 border-t border-zinc-800 bg-zinc-900/30 flex justify-end gap-3 shrink-0">
              <button onClick={() => { setIsMergeModalOpen(false); setSelectedForMerge([]); }} className="px-5 py-2.5 rounded-xl text-sm font-medium text-zinc-300 hover:text-white hover:bg-zinc-800 transition-all">
                取消
              </button>
              <button 
                onClick={handleMergeImages} 
                disabled={selectedForMerge.length < 2 || isProcessing}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-800 disabled:text-zinc-500 text-white px-6 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 transition-all shadow-lg shadow-indigo-500/20"
              >
                {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
                {isProcessing ? '合并中...' : `合并选中的 ${selectedForMerge.length} 张图片`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Asset Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 sm:p-6">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-6xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50 shrink-0">
              <h2 className="text-lg font-semibold text-zinc-100">添加新资产</h2>
              <button onClick={closeModal} className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all">
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-col lg:flex-row flex-1 overflow-hidden">
              
              {/* Left: Image Preview & Editor */}
              <div className="flex-1 bg-[#0a0a0a] p-6 flex flex-col items-center justify-center relative border-b lg:border-b-0 lg:border-r border-zinc-800 overflow-hidden min-h-[300px]">
                {!previewUrl ? (
                  <div className="w-full max-w-md border-2 border-dashed border-zinc-700 hover:border-indigo-500 bg-zinc-900/30 rounded-2xl p-12 text-center cursor-pointer transition-all" onClick={() => document.getElementById('asset-upload')?.click()}>
                    <input id="asset-upload" type="file" accept="image/*,audio/*" multiple className="hidden" onChange={handleFileSelect} />
                    <UploadCloud className="w-12 h-12 mx-auto mb-4 text-zinc-500" />
                    <h3 className="text-base font-medium text-zinc-300 mb-2">点击上传素材</h3>
                    <p className="text-xs text-zinc-500">支持批量上传，支持 JPG, PNG, WEBP, MP3, WAV</p>
                  </div>
                ) : (
                  <div className="relative w-full h-full flex items-center justify-center bg-zinc-900/20 rounded-xl p-4">
                    <div className="relative max-w-full max-h-full flex items-center justify-center w-full">
                      {file?.type.startsWith('audio/') ? (
                        <audio src={previewUrl} controls className="w-full max-w-md" />
                      ) : (
                        <div className="relative inline-block max-w-full max-h-[60vh]">
                          <img 
                            ref={imageRef}
                            src={(processMode === 'auto-split' || processMode === 'auto-single') && processedUrl ? processedUrl : previewUrl} 
                            alt="Preview" 
                            className="w-auto h-auto max-w-full max-h-[60vh] block rounded-lg shadow-2xl"
                            onLoad={setupCanvas}
                            draggable={false}
                          />
                          
                          <canvas
                            ref={canvasRef}
                            className={`absolute inset-0 w-full h-full cursor-crosshair touch-none rounded-lg ${processMode === 'manual' ? 'block' : 'hidden'}`}
                            onMouseDown={startDrawing}
                            onMouseMove={draw}
                            onMouseUp={stopDrawing}
                            onMouseLeave={stopDrawing}
                            onTouchStart={startDrawing}
                            onTouchMove={draw}
                            onTouchEnd={stopDrawing}
                          />
                        </div>
                      )}
                    </div>

                    <button 
                      onClick={() => document.getElementById('asset-upload-change')?.click()}
                      className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white px-3 py-1.5 rounded-lg text-xs backdrop-blur-md transition-all border border-white/10"
                    >
                      更换素材
                      <input id="asset-upload-change" type="file" accept="image/*,audio/*" className="hidden" onChange={handleFileSelect} />
                    </button>
                  </div>
                )}
              </div>

              {/* Right: Form Controls */}
              <div className="w-full lg:w-[400px] bg-zinc-900/30 p-6 overflow-y-auto custom-scrollbar flex flex-col gap-6 shrink-0">
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-1.5 flex justify-between items-center">
                      <span>资产名称</span>
                      {category === '服装' && (
                        <div className="flex gap-2 text-xs">
                          <button 
                            className="bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded hover:bg-indigo-500/20"
                            onClick={() => {
                              const base = "男主服装";
                              const exist = assets.filter(a => a.name.startsWith(base));
                              setName(exist.length > 0 ? `${base}${exist.length + 1}` : base);
                            }}
                          >男主服装</button>
                          <button 
                            className="bg-pink-500/10 text-pink-400 px-2 py-0.5 rounded hover:bg-pink-500/20"
                            onClick={() => {
                              const base = "女主服装";
                              const exist = assets.filter(a => a.name.startsWith(base));
                              setName(exist.length > 0 ? `${base}${exist.length + 1}` : base);
                            }}
                          >女主服装</button>
                        </div>
                      )}
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={category === '服装' ? '例如：男主服装1' : '例如：冷酷男主侧脸'}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-zinc-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-1.5">所属分类</label>
                    <select
                      value={category}
                      onChange={(e) => {
                        const newCat = e.target.value as Category;
                        setCategory(newCat);
                        if (newCat === '服装' && name.trim() !== '') {
                          // Clear if it's the original file name, or just clear it outright to prompt interaction
                          setName('');
                        }
                      }}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-zinc-200 appearance-none"
                    >
                      {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-1.5 flex items-center gap-2">
                      <Tag size={14} /> 标签打标
                    </label>
                    <input
                      type="text"
                      value={tagsInput}
                      onChange={(e) => setTagsInput(e.target.value)}
                      placeholder="输入标签，用逗号分隔 (例如: 黑发, 西装)"
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-zinc-200"
                    />
                  </div>
                </div>

                <div className={`space-y-4 pt-6 border-t border-zinc-800 ${!previewUrl ? 'opacity-50 pointer-events-none' : ''}`}>
                  <label className="block text-sm font-medium text-zinc-300">面部防检测处理 (可选)</label>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setProcessMode('none')}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all ${processMode === 'none' ? 'bg-zinc-800 border-zinc-600 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900'}`}
                    >
                      原图直出
                    </button>
                    <button
                      onClick={() => handleAutoProcess('auto-split')}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-1 ${processMode === 'auto-split' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900'}`}
                    >
                      <ImageIcon size={12} /> 仅保留头部
                    </button>
                    <button
                      onClick={() => handleAutoProcess('auto-single')}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-1 ${processMode === 'auto-single' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900'}`}
                    >
                      <Square size={12} /> 单图遮挡
                    </button>
                    <button
                      onClick={() => {
                        setProcessMode('manual');
                        setTimeout(setupCanvas, 50);
                      }}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-1 ${processMode === 'manual' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900'}`}
                    >
                      <MousePointer2 size={12} /> 手动涂黑
                    </button>
                  </div>

                  {processMode === 'auto-split' && (
                    <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-xl p-3">
                      <p className="text-xs text-zinc-400 leading-relaxed">系统将自动识别面部并仅保留头部，红色背景。若面部占比过大（大头照），将自动缩小比例至 20% 左右并进一步收紧面部遮罩以防拦截。</p>
                    </div>
                  )}
                  {processMode === 'auto-single' && (
                    <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-xl p-3">
                      <p className="text-xs text-zinc-400 leading-relaxed">在原图上使用红色色块同时遮挡面部与肩膀区域，保留原始背景。</p>
                    </div>
                  )}
                  {processMode === 'manual' && (
                    <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 flex flex-col gap-3">
                      <p className="text-xs text-zinc-400 leading-relaxed">请在左侧图片上直接使用鼠标/手指涂抹需要遮挡的区域。</p>
                      <button onClick={clearCanvas} className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-2">
                        <Eraser size={14} /> 清空涂鸦
                      </button>
                    </div>
                  )}
                  {isProcessing && <div className="text-xs text-indigo-400 flex items-center gap-2"><Loader2 size={14} className="animate-spin" /> 处理中...</div>}
                </div>

                <div className="mt-auto pt-6">
                  <button
                    onClick={handleSaveAsset}
                    disabled={!previewUrl || isProcessing}
                    className="w-full bg-white hover:bg-zinc-200 text-black py-3 rounded-xl text-sm font-bold transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
                    保存并添加到资产库
                  </button>
                </div>

              </div>
            </div>
          </div>
        </div>
      )}
      {/* Asset Selector Modal */}
      {/* (Existing asset selector modal code...) */}

      {/* Edit Asset Modal */}
      {isEditModalOpen && editingAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
              <h2 className="text-lg font-semibold text-zinc-100">编辑资产信息</h2>
              <button onClick={() => setIsEditModalOpen(false)} className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all">
                <X size={20} />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex justify-center mb-4">
                <div className="w-32 h-32 rounded-lg overflow-hidden border border-zinc-800">
                  {editingAsset.type === 'audio' ? (
                    <div className="w-full h-full flex items-center justify-center bg-zinc-900">
                      <ImageIcon size={32} className="text-zinc-600" />
                    </div>
                  ) : (
                    <img src={editingAsset.processedUrl || editingAsset.originalUrl} className="w-full h-full object-cover" />
                  )}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">资产名称</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-200 focus:ring-2 focus:ring-indigo-500/50 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">所属分类</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as Category)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-200 outline-none"
                >
                  {CATEGORIES.filter(c => c !== '全部').map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">标签 (逗号分隔)</label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-200 outline-none"
                />
              </div>
            </div>
            <div className="p-6 border-t border-zinc-800 bg-zinc-900/30 flex justify-end gap-3">
              <button onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 text-sm text-zinc-400 hover:text-white">取消</button>
              <button onClick={handleUpdateAsset} className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 rounded-xl text-sm font-medium">保存修改</button>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {previewAsset && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-md p-4 cursor-zoom-out"
          onClick={() => setPreviewAsset(null)}
        >
          <div className="relative max-w-full max-h-full flex flex-col items-center gap-4">
            <button 
              onClick={() => setPreviewAsset(null)}
              className="absolute -top-12 right-0 p-2 text-white/50 hover:text-white transition-colors"
            >
              <X size={32} />
            </button>
            <div className="flex gap-4 max-w-full overflow-x-auto p-4 custom-scrollbar">
              <div className="flex flex-col items-center gap-2 shrink-0">
                <p className="text-xs text-zinc-500 font-medium">原始图片</p>
                <img 
                  src={previewAsset.originalUrl} 
                  alt="Original" 
                  className="max-h-[75vh] object-contain rounded-lg shadow-2xl border border-zinc-800"
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
              {previewAsset.processedUrl && (
                <div className="flex flex-col items-center gap-2 shrink-0">
                  <p className="text-xs text-indigo-400 font-medium">处理后图片</p>
                  <img 
                    src={previewAsset.processedUrl} 
                    alt="Processed" 
                    className="max-h-[75vh] object-contain rounded-lg shadow-2xl border border-indigo-500/30"
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
              )}
            </div>
            <div className="bg-zinc-900/80 backdrop-blur-md border border-zinc-800 rounded-2xl px-6 py-3 flex flex-col items-center gap-1 shadow-2xl">
              <h3 className="text-lg font-semibold text-white">{previewAsset.name}</h3>
              <div className="flex gap-2">
                {previewAsset.tags.map(tag => (
                  <span key={tag} className="text-xs text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-full border border-zinc-700">{tag}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
