import { useState, useEffect } from 'react';
import { Settings, Sparkles, Copy, Check, Wand2, Key, Cpu, AlignLeft, Save, Tag, Languages, Terminal, X, RefreshCw, Trash2, Bookmark, Plus, Edit2, ChevronDown, ChevronRight } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useStore } from '@/store/useStore';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const DEFAULT_SYSTEM_PROMPT = `你是一名顶级建模师，审美高超，并且明白时代风俗，引领女性当下审美，请你根据以下描述为我生成一份mj提示词：

要求：
1. 画面必须是人物的中景（Medium shot）或近景特写（Close-up），绝对不要远景。
2. 强调面部细节（highly detailed face, realistic skin texture, beautiful eyes, intricate details）。
3. 风格为真人写实、短剧建模脸、cosplay质感（photorealistic, hyper-realistic, 8k, unreal engine 5 render style, cinematic）。
4. 灯光必须优秀（cinematic lighting, soft studio lighting, rim light, dramatic lighting）。
5. 镜头语言（85mm lens, depth of field, bokeh）。
6. 请直接输出一段英文的Midjourney提示词，用逗号分隔，并在最后加上 --ar 3:4 --v 6.0 --style raw。不需要任何解释、翻译和多余的话。`;

const TAG_CATEGORIES = [
  {
    name: '身份标签',
    tags: ['皇子', '王爷', '剑客', '书生', '刺客', '帝王', '将军', '仙尊', '魔尊', '霸总', '医生', '侦探', '贵族']
  },
  {
    name: '性格标签',
    tags: ['开朗阳光', '阴郁冷淡', '桀骜不驯', '温柔腹黑', '偏执病娇', '慵懒随性', '傲娇毒舌', '沉稳内敛', '疯批美人', '纯情修勾', '高冷禁欲', '狡黠多端']
  },
  {
    name: '特征标签',
    tags: ['禁欲系', '一丝风流', '战损妆', '泪痣', '金丝眼镜', '长发披肩', '异瞳', '苍白病弱', '肌肉线条', '半遮面', '清冷感', '病娇感', '高挺鼻梁']
  }
];

type Provider = 'deepseek' | 'doubao';
const PROVIDERS: { id: Provider, name: string }[] = [
  { id: 'deepseek', name: 'DeepSeek' },
  { id: 'doubao', name: '豆包' }
];

type ResultState = {
  loading: boolean;
  result: string;
  error: string;
  translation: string;
  translating: boolean;
};

const INITIAL_RESULTS: Record<Provider, ResultState> = {
  deepseek: { loading: false, result: '', error: '', translation: '', translating: false },
  doubao: { loading: false, result: '', error: '', translation: '', translating: false },
};

type ModalState = {
  isOpen: boolean;
  type: 'prompt' | 'confirm';
  title: string;
  message?: string;
  defaultValue?: string;
  onConfirm: (value?: string) => void;
  onCancel: () => void;
};

export default function PromptGenerator() {
  const { favorites, addFavorite, removeFavorite, setFavorites, prompts, updatePrompts } = useStore();
  
  const [selectedProviders, setSelectedProviders] = useState<Provider[]>(['deepseek']);
  const [doubaoModelId, setDoubaoModelId] = useState('');
  const [deepseekModelId, setDeepseekModelId] = useState('');
  
  const systemPrompt = prompts.globalSystemPrompt;
  const setSystemPrompt = (val: string) => updatePrompts({ globalSystemPrompt: val });

  const [keywords, setKeywords] = useState('');
  
  const [results, setResults] = useState<Record<Provider, ResultState>>(INITIAL_RESULTS);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [globalError, setGlobalError] = useState('');
  
  // Tags state
  const [tagCategories, setTagCategories] = useState(TAG_CATEGORIES);
  const [isEditingTags, setIsEditingTags] = useState(false);

  const [showFavorites, setShowFavorites] = useState(false);
  const [expandedFavs, setExpandedFavs] = useState<Set<string>>(new Set());

  const toggleFav = (id: string) => {
    setExpandedFavs(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Modal state
  const [modal, setModal] = useState<ModalState>({
    isOpen: false,
    type: 'confirm',
    title: '',
    onConfirm: () => {},
    onCancel: () => {}
  });

  // Logs state
  const [showLogs, setShowLogs] = useState(false);
  const [serverLogs, setServerLogs] = useState<{timestamp: string, level: string, message: string}[]>([]);
  const [isFetchingLogs, setIsFetchingLogs] = useState(false);

  const fetchLogs = async () => {
    setIsFetchingLogs(true);
    try {
      const res = await fetch('/api/logs');
      const data = await res.json();
      setServerLogs(data);
    } catch (e) {
      console.error("Failed to fetch logs", e);
    } finally {
      setIsFetchingLogs(false);
    }
  };

  const clearLogs = async () => {
    try {
      await fetch('/api/logs', { method: 'DELETE' });
      setServerLogs([]);
    } catch (e) {
      console.error("Failed to clear logs", e);
    }
  };

  useEffect(() => {
    if (showLogs) {
      fetchLogs();
      const interval = setInterval(fetchLogs, 3000);
      return () => clearInterval(interval);
    }
  }, [showLogs]);

  // Load settings from localStorage
  useEffect(() => {
    const savedProviders = localStorage.getItem('mj_selectedProviders');
    if (savedProviders) setSelectedProviders(JSON.parse(savedProviders));

    const savedDoubaoModelId = localStorage.getItem('mj_doubaoModelId');
    if (savedDoubaoModelId) setDoubaoModelId(savedDoubaoModelId);

    const savedDeepseekModelId = localStorage.getItem('mj_deepseekModelId');
    if (savedDeepseekModelId) setDeepseekModelId(savedDeepseekModelId);

    const savedTags = localStorage.getItem('mj_tagCategories');
    if (savedTags) setTagCategories(JSON.parse(savedTags));

    const savedFavs = localStorage.getItem('mj_favorites');
    if (savedFavs) setFavorites(JSON.parse(savedFavs));
  }, []);

  const handleSaveSettings = () => {
    localStorage.setItem('mj_selectedProviders', JSON.stringify(selectedProviders));
    localStorage.setItem('mj_doubaoModelId', doubaoModelId);
    localStorage.setItem('mj_deepseekModelId', deepseekModelId);
    localStorage.setItem('mj_tagCategories', JSON.stringify(tagCategories));
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleTagClick = (tag: string) => {
    setKeywords(prev => {
      const separator = prev.trim() && !prev.endsWith('，') && !prev.endsWith(',') ? '，' : '';
      return prev + separator + tag;
    });
  };

  const handleAddTag = (categoryName: string) => {
    setModal({
      isOpen: true,
      type: 'prompt',
      title: `添加标签到【${categoryName}】`,
      message: '请输入新标签的名称：',
      defaultValue: '',
      onConfirm: (newTag) => {
        if (newTag && newTag.trim()) {
          setTagCategories(prev => prev.map(c => 
            c.name === categoryName && !c.tags.includes(newTag.trim())
              ? { ...c, tags: [...c.tags, newTag.trim()] }
              : c
          ));
        }
        setModal(prev => ({ ...prev, isOpen: false }));
      },
      onCancel: () => setModal(prev => ({ ...prev, isOpen: false }))
    });
  };

  const handleRemoveTag = (categoryName: string, tagToRemove: string) => {
    setModal({
      isOpen: true,
      type: 'confirm',
      title: '删除标签',
      message: `确定要删除标签【${tagToRemove}】吗？`,
      onConfirm: () => {
        setTagCategories(prev => prev.map(c => 
          c.name === categoryName 
            ? { ...c, tags: c.tags.filter(t => t !== tagToRemove) }
            : c
        ));
        setModal(prev => ({ ...prev, isOpen: false }));
      },
      onCancel: () => setModal(prev => ({ ...prev, isOpen: false }))
    });
  };

  const handleSaveFavorite = (prompt: string, translation: string) => {
    setModal({
      isOpen: true,
      type: 'prompt',
      title: '收藏提示词',
      message: '请为这个提示词命名：',
      defaultValue: `提示词 ${new Date().toLocaleDateString()}`,
      onConfirm: (name) => {
        if (name) {
          const newFav = {
            id: Date.now().toString(),
            name: name.trim() || '未命名',
            prompt,
            translation
          };
          addFavorite(newFav);
          // Also save to local storage for persistence
          const savedFavs = localStorage.getItem('mj_favorites');
          const parsed = savedFavs ? JSON.parse(savedFavs) : [];
          localStorage.setItem('mj_favorites', JSON.stringify([newFav, ...parsed]));
        }
        setModal(prev => ({ ...prev, isOpen: false }));
      },
      onCancel: () => setModal(prev => ({ ...prev, isOpen: false }))
    });
  };

  const handleDeleteFavorite = (id: string) => {
    setModal({
      isOpen: true,
      type: 'confirm',
      title: '删除收藏',
      message: '确定要删除这个收藏吗？',
      onConfirm: () => {
        removeFavorite(id);
        const savedFavs = localStorage.getItem('mj_favorites');
        if (savedFavs) {
          const parsed = JSON.parse(savedFavs);
          localStorage.setItem('mj_favorites', JSON.stringify(parsed.filter((f: any) => f.id !== id)));
        }
        setModal(prev => ({ ...prev, isOpen: false }));
      },
      onCancel: () => setModal(prev => ({ ...prev, isOpen: false }))
    });
  };

  const handleGenerate = async () => {
    if (!keywords.trim()) {
      setGlobalError('请输入人物描述词组');
      return;
    }
    if (selectedProviders.length === 0) {
      setGlobalError('请至少选择一个模型');
      return;
    }
    
    setGlobalError('');
    setIsGenerating(true);
    
    // Reset results for selected providers
    setResults(prev => {
      const next = { ...prev };
      selectedProviders.forEach(p => {
        next[p] = { loading: true, result: '', error: '', translation: '', translating: false };
      });
      return next;
    });

    await Promise.all(selectedProviders.map(async (p) => {
      try {
        const response = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            provider: p,
            apiKey: useStore.getState().apiKeys.globalApiKey,
            modelId: p === 'doubao' ? useStore.getState().apiKeys.doubaoId : useStore.getState().apiKeys.deepseekId,
            systemPrompt,
            userKeywords: keywords,
          }),
        });

        const text = await response.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch (err) {
          throw new Error(`服务器响应异常: ${text.slice(0, 60)}...`);
        }

        if (!response.ok) {
          const errorMsg = data.details 
            ? `${data.error || '生成失败'} - 详情: ${typeof data.details === 'object' ? JSON.stringify(data.details) : data.details}`
            : (data.error || '生成失败');
          throw new Error(errorMsg);
        }

        setResults(prev => ({
          ...prev,
          [p]: { ...prev[p], loading: false, result: data.result }
        }));

        // Auto translate
        handleTranslate(p, data.result);
      } catch (err: any) {
        setResults(prev => ({
          ...prev,
          [p]: { ...prev[p], loading: false, error: err.message }
        }));
      }
    }));

    setIsGenerating(false);
  };

  const handleTranslate = async (pId: Provider, textToTranslateOverride?: string) => {
    const textToTranslate = textToTranslateOverride || results[pId].result;
    if (!textToTranslate) return;

    setResults(prev => ({ ...prev, [pId]: { ...prev[pId], translating: true, error: '' } }));

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: pId,
          apiKey: useStore.getState().apiKeys.globalApiKey,
          modelId: pId === 'doubao' ? useStore.getState().apiKeys.doubaoId : useStore.getState().apiKeys.deepseekId,
          text: textToTranslate,
        }),
      });

      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (err) {
        throw new Error(`翻译异常: ${text.slice(0, 60)}...`);
      }

      if (!response.ok) {
        const errorMsg = data.details 
          ? `${data.error || '翻译失败'} - 详情: ${typeof data.details === 'object' ? JSON.stringify(data.details) : data.details}`
          : (data.error || '翻译失败');
        throw new Error(errorMsg);
      }

      setResults(prev => ({
        ...prev,
        [pId]: { ...prev[pId], translating: false, translation: data.result }
      }));
    } catch (err: any) {
      setResults(prev => ({
        ...prev,
        [pId]: { ...prev[pId], translating: false, error: err.message }
      }));
    }
  };

  const copyToClipboard = async (text: string, id: string) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="h-full bg-zinc-950 text-zinc-100 font-sans selection:bg-indigo-500/30 overflow-hidden">
      <div className="max-w-7xl mx-auto p-4 md:p-6 lg:p-8 flex flex-col lg:flex-row gap-8 h-full">
        
        {/* Left Sidebar - Settings */}
        <aside className="w-full lg:w-96 flex-shrink-0 flex flex-col gap-6 bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 overflow-y-auto custom-scrollbar">
          <div className="flex items-center gap-3 pb-4 border-b border-zinc-800">
            <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
              <Wand2 size={24} />
            </div>
            <div>
              <h1 className="text-xl font-semibold tracking-tight">MJ Prompt Gen</h1>
              <p className="text-xs text-zinc-400">短剧/Cosplay 人物面部参考</p>
            </div>
          </div>

          {/* API Configuration */}
          <div className="space-y-4">
            <h2 className="text-sm font-medium text-zinc-300 flex items-center gap-2">
              <Cpu size={16} />
              模型选择 (可多选对比)
            </h2>
            <p className="text-xs text-zinc-500">
              请确保在下方的“全局配置”中已填写对应的 API 密钥和推理 ID。
            </p>
            
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {PROVIDERS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedProviders(prev => 
                        prev.includes(p.id) 
                          ? prev.filter(x => x !== p.id)
                          : [...prev, p.id]
                      );
                    }}
                    className={cn(
                      "py-2 px-3 text-xs font-medium rounded-lg border transition-all flex items-center gap-2",
                      selectedProviders.includes(p.id)
                        ? "bg-indigo-500/10 border-indigo-500/50 text-indigo-300" 
                        : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-300"
                    )}
                  >
                    <div className={cn("w-2 h-2 rounded-full", selectedProviders.includes(p.id) ? "bg-indigo-400" : "bg-zinc-600")} />
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Prompt Template */}
          <div className="space-y-4 pt-4 border-t border-zinc-800 flex-1 flex flex-col">
            <h2 className="text-sm font-medium text-zinc-300 flex items-center gap-2">
              <AlignLeft size={16} />
              系统提示词模板
            </h2>
            <p className="text-xs text-zinc-500">
              固定句式与规则，可根据需要微调。
            </p>
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="w-full flex-1 min-h-[200px] bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-3 text-xs leading-relaxed focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 resize-none custom-scrollbar"
            />
          </div>

          {/* Save Button */}
          <button
            onClick={handleSaveSettings}
            className="w-full mt-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all"
          >
            {isSaved ? (
              <>
                <Check size={16} className="text-green-400" />
                <span className="text-green-400">已保存配置</span>
              </>
            ) : (
              <>
                <Save size={16} />
                手动保存配置
              </>
            )}
          </button>

          {/* View Logs Button */}
          <button
            onClick={() => setShowLogs(true)}
            className="w-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all"
          >
            <Terminal size={16} />
            查看服务器日志
          </button>

          {/* View Favorites Button */}
          <button
            onClick={() => setShowFavorites(true)}
            className="w-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-indigo-400 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all"
          >
            <Bookmark size={16} />
            我的收藏夹 ({favorites.length})
          </button>
        </aside>

        {/* Right Main Area - Generator */}
        <main className="flex-1 flex flex-col gap-6 h-full overflow-y-auto pb-8 custom-scrollbar">
          
          {/* Tags Area */}
          <div className="flex flex-col gap-4 bg-zinc-900/30 border border-zinc-800/50 rounded-xl p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-zinc-300 flex items-center gap-2">
                <Tag size={16} />
                快捷灵感标签
              </h3>
              <button 
                onClick={() => setIsEditingTags(!isEditingTags)}
                className={cn("text-xs flex items-center gap-1 transition-all", isEditingTags ? "text-indigo-400" : "text-zinc-500 hover:text-zinc-300")}
              >
                <Edit2 size={12} />
                {isEditingTags ? '完成编辑' : '编辑标签'}
              </button>
            </div>
            <div className="flex flex-col gap-3">
              {tagCategories.map(category => (
                <div key={category.name} className="flex items-start gap-3">
                  <span className="text-xs text-zinc-500 whitespace-nowrap mt-1.5 min-w-[60px]">{category.name}：</span>
                  <div className="flex flex-wrap gap-2">
                    {category.tags.map(tag => (
                      <button
                        key={tag}
                        onClick={() => isEditingTags ? handleRemoveTag(category.name, tag) : handleTagClick(tag)}
                        className={cn(
                          "px-2.5 py-1 text-xs rounded-md transition-all border",
                          isEditingTags 
                            ? "bg-zinc-800/30 text-zinc-400 border-dashed border-zinc-600 hover:border-red-500 hover:text-red-400" 
                            : "bg-zinc-800/50 text-zinc-300 hover:bg-indigo-500/20 hover:text-indigo-300 border-zinc-700/50 hover:border-indigo-500/30"
                        )}
                      >
                        {tag}
                        {isEditingTags && <X size={10} className="inline ml-1 opacity-50" />}
                      </button>
                    ))}
                    {isEditingTags && (
                      <button
                        onClick={() => handleAddTag(category.name)}
                        className="px-2.5 py-1 text-xs bg-zinc-800/20 text-zinc-500 border border-dashed border-zinc-700 rounded-md hover:text-zinc-300 hover:border-zinc-500 transition-all flex items-center gap-1"
                      >
                        <Plus size={10} /> 添加
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-zinc-300">人物特征描述词组</label>
              {keywords && (
                <button 
                  onClick={() => setKeywords('')}
                  className="text-xs text-zinc-500 hover:text-red-400 flex items-center gap-1 transition-colors"
                >
                  <Trash2 size={14} /> 清空全部
                </button>
              )}
            </div>
            <div className="relative">
              <textarea
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="输入词组，例如：赛博朋克，霓虹灯，可爱女孩，银色短发，机能风外套..."
                className="w-full h-32 bg-zinc-900/50 border border-zinc-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all resize-none placeholder:text-zinc-600 custom-scrollbar"
              />
              <button
                onClick={handleGenerate}
                disabled={isGenerating || !keywords.trim() || selectedProviders.length === 0}
                className="absolute bottom-3 right-3 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/20"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    生成中...
                  </>
                ) : (
                  <>
                    <Sparkles size={16} />
                    多模型生成
                  </>
                )}
              </button>
            </div>
            {globalError && <p className="text-red-400 text-xs mt-1">{globalError}</p>}
          </div>

          {/* Output Area (Grid for comparison) */}
          <div className="flex-1 flex flex-col gap-4">
            <label className="text-sm font-medium text-zinc-300">生成结果对比</label>
            
            {selectedProviders.length === 0 && (
              <div className="text-zinc-600 text-sm text-center py-10 border border-dashed border-zinc-800 rounded-xl">
                请在左侧选择至少一个模型
              </div>
            )}

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {selectedProviders.map(pId => {
                const res = results[pId];
                const providerName = PROVIDERS.find(x => x.id === pId)?.name;
                
                // If not loading and no result and no error, it means it hasn't started yet
                if (!res.loading && !res.result && !res.error && !isGenerating) return null;

                return (
                  <div key={pId} className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 flex flex-col gap-3 relative overflow-hidden">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={cn("w-2 h-2 rounded-full", res.loading ? "bg-yellow-500 animate-pulse" : res.error ? "bg-red-500" : "bg-green-500")} />
                        <span className="text-sm font-medium text-zinc-200">{providerName}</span>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleSaveFavorite(res.result, res.translation)}
                          disabled={!res.result || res.loading}
                          className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 transition-all disabled:opacity-50"
                        >
                          <Bookmark size={14} />
                          收藏
                        </button>
                        <button
                          onClick={() => handleTranslate(pId)}
                          disabled={res.translating || !res.result || res.loading}
                          className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white transition-all disabled:opacity-50"
                        >
                          {res.translating ? (
                            <div className="w-3 h-3 border-2 border-zinc-400 border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <Languages size={14} />
                          )}
                          翻译
                        </button>
                        <button
                          onClick={() => copyToClipboard(res.result, pId)}
                          disabled={!res.result || res.loading}
                          className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white transition-all disabled:opacity-50"
                        >
                          {copiedId === pId ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                          {copiedId === pId ? '已复制' : '复制'}
                        </button>
                      </div>
                    </div>

                    {/* Content */}
                    {res.loading ? (
                      <div className="h-32 flex items-center justify-center text-zinc-500 text-sm gap-2">
                        <div className="w-4 h-4 border-2 border-zinc-600 border-t-zinc-400 rounded-full animate-spin" />
                        正在生成提示词...
                      </div>
                    ) : res.error ? (
                      <div className="h-32 flex items-center justify-center text-red-400 text-xs p-4 text-center bg-red-500/5 rounded-lg border border-red-500/10">
                        {res.error}
                      </div>
                    ) : (
                      <div className="flex flex-col gap-3">
                        <textarea
                          readOnly
                          value={res.result}
                          className="w-full h-32 bg-zinc-950/50 border border-zinc-800/80 rounded-lg px-3 py-3 text-xs font-mono leading-relaxed focus:outline-none transition-all resize-none text-zinc-300 custom-scrollbar"
                        />
                        {res.translation && (
                          <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-lg text-xs leading-relaxed text-zinc-300">
                            <span className="text-indigo-400 font-medium mb-1.5 flex items-center gap-1.5">
                              <Languages size={14} />
                              中文翻译：
                            </span>
                            {res.translation}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </main>
      </div>

      {/* Favorites Modal */}
      {showFavorites && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-4xl h-[80vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
              <div className="flex items-center gap-3">
                <Bookmark size={20} className="text-indigo-400" />
                <h2 className="text-lg font-medium text-zinc-200">我的收藏夹</h2>
              </div>
              <button
                onClick={() => setShowFavorites(false)}
                className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-all"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 bg-[#0d0d0d] custom-scrollbar">
              {favorites.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-zinc-600 text-sm gap-3">
                  <Bookmark size={48} className="opacity-20" />
                  <p>暂无收藏的提示词</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {favorites.map(fav => (
                    <div key={fav.id} className="bg-zinc-900/60 border border-zinc-800 rounded-xl flex flex-col overflow-hidden transition-all">
                      <div 
                        className="flex items-center justify-between p-4 cursor-pointer hover:bg-zinc-800/50 transition-colors"
                        onClick={() => toggleFav(fav.id)}
                      >
                        <div className="flex items-center gap-2">
                          {expandedFavs.has(fav.id) ? <ChevronDown size={16} className="text-zinc-500" /> : <ChevronRight size={16} className="text-zinc-500" />}
                          <h3 className="text-sm font-medium text-zinc-200">{fav.name}</h3>
                        </div>
                        <div className="flex gap-2" onClick={e => e.stopPropagation()}>
                          <button
                            onClick={() => copyToClipboard(fav.prompt, `fav-${fav.id}`)}
                            className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white transition-all"
                          >
                            {copiedId === `fav-${fav.id}` ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                            {copiedId === `fav-${fav.id}` ? '已复制' : '复制英文'}
                          </button>
                          <button
                            onClick={() => handleDeleteFavorite(fav.id)}
                            className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all"
                          >
                            <Trash2 size={14} />
                            删除
                          </button>
                        </div>
                      </div>
                      {expandedFavs.has(fav.id) && (
                        <div className="flex flex-col gap-2 p-4 pt-0 border-t border-zinc-800/50 mt-2">
                          <div className="p-3 bg-zinc-950/50 border border-zinc-800/80 rounded-lg text-xs font-mono leading-relaxed text-zinc-300">
                            {fav.prompt}
                          </div>
                          {fav.translation && (
                            <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-lg text-xs leading-relaxed text-zinc-300">
                              <span className="text-indigo-400 font-medium mb-1.5 flex items-center gap-1.5">
                                <Languages size={14} />
                                中文翻译：
                              </span>
                              {fav.translation}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Logs Modal */}
      {showLogs && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-4xl h-[80vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
              <div className="flex items-center gap-3">
                <Terminal size={20} className="text-indigo-400" />
                <h2 className="text-lg font-medium text-zinc-200">服务器实时日志</h2>
                {isFetchingLogs && <div className="w-4 h-4 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin ml-2" />}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={fetchLogs}
                  className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-all"
                  title="刷新"
                >
                  <RefreshCw size={18} />
                </button>
                <button
                  onClick={clearLogs}
                  className="p-2 text-zinc-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                  title="清空"
                >
                  <Trash2 size={18} />
                </button>
                <div className="w-px h-6 bg-zinc-800 mx-2" />
                <button
                  onClick={() => setShowLogs(false)}
                  className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-all"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 bg-[#0d0d0d] custom-scrollbar">
              {serverLogs.length === 0 ? (
                <div className="h-full flex items-center justify-center text-zinc-600 text-sm">
                  暂无日志记录
                </div>
              ) : (
                <div className="flex flex-col gap-1">
                  {serverLogs.map((log, i) => (
                    <div key={i} className="font-mono text-xs flex gap-3 py-1 border-b border-zinc-900/50 hover:bg-zinc-900/30 px-2 rounded">
                      <span className="text-zinc-600 shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString('zh-CN', { hour12: false, fractionalSecondDigits: 3 })}
                      </span>
                      <span className={cn(
                        "shrink-0 w-12 uppercase font-bold",
                        log.level === 'error' ? 'text-red-500' : 'text-blue-400'
                      )}>
                        [{log.level}]
                      </span>
                      <span className={cn(
                        "break-all whitespace-pre-wrap",
                        log.level === 'error' ? 'text-red-300' : 'text-zinc-300'
                      )}>
                        {log.message}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Custom Modal for Prompt/Confirm */}
      {modal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-md shadow-2xl overflow-hidden">
            <div className="p-6">
              <h3 className="text-lg font-medium text-zinc-100 mb-2">{modal.title}</h3>
              {modal.message && <p className="text-sm text-zinc-400 mb-4">{modal.message}</p>}
              
              {modal.type === 'prompt' && (
                <input
                  autoFocus
                  type="text"
                  defaultValue={modal.defaultValue}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      modal.onConfirm(e.currentTarget.value);
                    } else if (e.key === 'Escape') {
                      modal.onCancel();
                    }
                  }}
                  id="modal-prompt-input"
                />
              )}
            </div>
            <div className="px-6 py-4 bg-zinc-950/50 border-t border-zinc-800 flex justify-end gap-3">
              <button
                onClick={modal.onCancel}
                className="px-4 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-200 transition-colors"
              >
                取消
              </button>
              <button
                onClick={() => {
                  if (modal.type === 'prompt') {
                    const input = document.getElementById('modal-prompt-input') as HTMLInputElement;
                    modal.onConfirm(input?.value);
                  } else {
                    modal.onConfirm();
                  }
                }}
                className="px-4 py-2 text-sm font-medium bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors"
              >
                确定
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
