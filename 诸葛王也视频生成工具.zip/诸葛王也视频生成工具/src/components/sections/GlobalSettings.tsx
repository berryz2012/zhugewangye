import { useState } from 'react';
import { Settings, Key, X, Check } from 'lucide-react';
import { useStore } from '@/store/useStore';

export default function GlobalSettings() {
  const { apiKeys, updateApiKeys } = useStore();
  const [showTutorial, setShowTutorial] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = async () => {
    try {
      const currentState = useStore.getState();
      await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: 'ai-short-drama-storage', value: JSON.stringify({ state: currentState }) })
      });
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2000);
    } catch (err) {
      console.error('Failed to sync to disk', err);
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shrink-0 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold flex items-center gap-2 text-zinc-100">
          <Settings className="text-indigo-400" size={24} />
          全局配置与 API 密钥
        </h2>
        <button 
          onClick={() => setShowTutorial(true)}
          className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shadow-sm"
        >
          查看 API 接入教程
        </button>
      </div>

      <div className="flex flex-col gap-4 bg-zinc-950 p-5 rounded-2xl border border-zinc-800">
        <div>
          <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider flex items-center gap-2">
            <Key size={14} /> 全局 API 密钥
          </label>
          <input 
            type="password"
            value={apiKeys.globalApiKey}
            onChange={(e) => updateApiKeys({ globalApiKey: e.target.value })}
            placeholder="输入统一的火山引擎 API Key..."
            className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">Doubao 文本推理 ID</label>
            <input 
              type="text"
              value={apiKeys.doubaoId}
              onChange={(e) => updateApiKeys({ doubaoId: e.target.value })}
              placeholder="ep-xxx"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">DeepSeek 文本推理 ID</label>
            <input 
              type="text"
              value={apiKeys.deepseekId}
              onChange={(e) => updateApiKeys({ deepseekId: e.target.value })}
              placeholder="ep-xxx"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">Seedance 2.0 推理 ID</label>
            <input 
              type="text"
              value={apiKeys.seedanceId}
              onChange={(e) => updateApiKeys({ seedanceId: e.target.value })}
              placeholder="ep-xxx"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">Seedance 2.0 Fast 推理 ID</label>
            <input 
              type="text"
              value={apiKeys.seedanceFastId}
              onChange={(e) => updateApiKeys({ seedanceFastId: e.target.value })}
              placeholder="ep-xxx"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 font-mono"
            />
          </div>
        </div>
        
        <div className="flex justify-end mt-2">
          <button
            onClick={handleSave}
            className={`flex items-center gap-2 px-6 py-2 rounded-lg font-semibold text-sm transition-all duration-300 ${
              isSaved 
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' 
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20'
            }`}
          >
            {isSaved ? <><Check size={16} /> 已保存</> : '保存配置'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">教学视频链接</p>
            <h4 className="text-zinc-200 text-sm font-medium">官方使用教学视频 (B站)</h4>
          </div>
          <a 
            href="https://www.bilibili.com/video/BV1a3oTBEEpa/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-indigo-400 hover:text-indigo-300 text-xs font-semibold bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20 transition-all"
          >
            点击打开链接
          </a>
        </div>
        
        <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">后续更新链接</p>
            <h4 className="text-zinc-200 text-sm font-medium">项目源码与版本更新 (GitHub)</h4>
          </div>
          <a 
            href="https://github.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-indigo-400 hover:text-indigo-300 text-xs font-semibold bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20 transition-all"
          >
            点击打开链接
          </a>
        </div>
      </div>

      {showTutorial && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-8 w-full max-w-3xl shadow-2xl relative">
            <button 
              onClick={() => setShowTutorial(false)}
              className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white bg-zinc-900 hover:bg-zinc-800 rounded-full transition-colors"
            >
              <X size={18} />
            </button>
            <h3 className="text-xl font-bold text-zinc-100 mb-6">API 接入教程与 ID 配置指引</h3>
            <div className="text-sm text-zinc-300 space-y-6 max-h-[65vh] overflow-y-auto custom-scrollbar pr-4">
              <div className="p-5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                <p className="font-semibold text-indigo-300 mb-4">获取 API 密钥与开通服务步骤：</p>
                <ol className="list-decimal pl-5 space-y-4 text-zinc-400 leading-relaxed">
                  <li>
                    <strong>注册并登录</strong> 火山引擎 (Volcengine) 平台。
                  </li>
                  <li>
                    <strong>生成和获取 API Key</strong> (<span className="text-zinc-500 text-xs">备注：点击这个窗口即可登录注册</span>)。<br/>
                    <a href="https://console.volcengine.com/ark/region:ark+cn-beijing/apiKey?apikey=%7B%7D" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-indigo-300 underline mt-1 inline-block">点击打开链接</a>
                  </li>
                  <li>
                    <strong>开通模型服务</strong> (<span className="text-zinc-500 text-xs">搜索开通 Doubao, DeepSeek, Seedance等</span>)。<br/>
                    <a href="https://console.volcengine.com/ark/region:ark+cn-beijing/openManagement?COMPUTER_VISION=%7B%7D&LLM=%7B%22PageSize%22%3A10%2C%22PageNumber%22%3A1%2C%22Filter%22%3A%7B%22VendorNameOrModelName%22%3A%5B%7B%22key%22%3A%22name%22%2C%22value%22%3A%22doubao%22%7D%5D%7D%7D&advancedActiveKey=model&tab=LLM" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-indigo-300 underline mt-1 inline-block">点击打开链接</a>
                  </li>
                  <li>
                    <strong>创建并获取推理接入点 (Endpoint ID)</strong>：配置好各个模型后，将以 <code className="bg-zinc-800 px-1 py-0.5 rounded text-indigo-300 text-xs">ep-</code> 开头的 ID 复制。<br/>
                    <a href="https://console.volcengine.com/ark/region:ark+cn-beijing/endpoint/create" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-indigo-300 underline mt-1 inline-block">点击打开链接</a>
                  </li>
                </ol>
              </div>
              
              <div className="flex flex-col gap-2">
                <p className="text-zinc-500 font-medium border-t border-zinc-800 pt-4">资源链接指引：</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-900 rounded-lg p-3 border border-zinc-800/50 flex flex-col items-center justify-center gap-1">
                    <span className="text-[10px] text-zinc-500 uppercase">教学视频 (B站)</span>
                    <a 
                      href="https://www.bilibili.com/video/BV1a3oTBEEpa/" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-indigo-400 hover:text-indigo-300 text-xs font-medium transition-colors"
                    >
                      点击打开链接
                    </a>
                  </div>
                  <div className="bg-zinc-900 rounded-lg p-3 border border-zinc-800/50 flex flex-col items-center justify-center gap-1">
                    <span className="text-[10px] text-zinc-500 uppercase">后续更新 (GitHub)</span>
                    <a 
                      href="https://github.com/" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-indigo-400 hover:text-indigo-300 text-xs font-medium transition-colors"
                    >
                      点击打开链接
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
