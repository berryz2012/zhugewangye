import React, { useState } from 'react';
import { useStore } from '@/store/useStore';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { 
  ChevronDown, ChevronRight, Play, Loader2, Film, Settings2, 
  Image as ImageIcon, Bookmark, Plus, Trash2, Copy, Save, 
  X, GripVertical, Key, Zap, Maximize2, Edit3, Eye, Clock, Tag, AlertCircle, RefreshCw, PlayCircle, HelpCircle
} from 'lucide-react';
import { generateSeedanceVideo } from '@/lib/seedanceApi';

export default function VideoSettings() {
  const { 
    acts, prompts, updatePrompts, updateAct, assets, 
    apiKeys, updateApiKeys, savedPrompts, addSavedPrompt, 
    removeSavedPrompt, reorderLinkedAssets, addLog,
    activeSeedanceModel, setActiveSeedanceModel,
    scenePrompts: storeScenePrompts, setScenePrompts
  } = useStore();

  const scenePrompts = storeScenePrompts || [
    { id: 'default', name: '预设A1 (标准)', content: prompts?.systemA || '你是一名顶级短剧导演，审美高超，请你根据以下剧本内容拍摄一段真人短剧视频:\n场景:白天，室外，参考图1\n【关联资产】' }
  ];

  const helpUrl = "https://docs.volcengine.com/docs/ark/1255858"; // Placeholder help URL
  
  const [showA, setShowA] = useState(false);
  const [showC, setShowC] = useState(false);
  const [showPromptManager, setShowPromptManager] = useState(false);
  const [newPromptName, setNewPromptName] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [editingActId, setEditingActId] = useState<string | null>(null);
  const [tempShots, setTempShots] = useState<any[]>([]);
  const [expandedPromptActId, setExpandedPromptActId] = useState<string | null>(null);

  React.useEffect(() => {
    const generatingCount = acts.filter(a => a.status === 'generating').length;
    if (generatingCount < 3) {
      const nextAct = acts.find(a => a.status === 'queued');
      if (nextAct) {
        updateAct(nextAct.id, { status: 'generating' });
        setTimeout(() => {
          handleGenerateVideo(nextAct.id);
        }, 50);
      }
    }
  }, [acts, updateAct]);

  const enqueueGeneration = (actId: string) => {
    const usingId = activeSeedanceModel === 'fast' ? apiKeys.seedanceFastId : apiKeys.seedanceId;

    if (!apiKeys.globalApiKey || !usingId) {
      addLog({ type: 'error', title: '配置错误', details: '未检测到全局 API 密钥或选中的 Seedance 推理 ID，请在全局配置中填写。' });
      alert('请先在全下方的全局配置中填写全局 API 密钥和选定的模型推理 ID');
      return;
    }

    const { acts: currentActs } = useStore.getState();
    const generatingCount = currentActs.filter(a => a.status === 'generating').length;

    if (generatingCount >= 3) {
      updateAct(actId, { status: 'queued' });
      addLog({ type: 'info', title: '已加入队列', details: `当前并发生成任务达到上限(3个)，幕 [${actId.substring(0, 8)}] 已进入排队...` });
    } else {
      updateAct(actId, { status: 'generating' });
      setTimeout(() => {
        handleGenerateVideo(actId);
      }, 50);
    }
  };

  const handleGenerateVideo = async (actId: string, retryCount = 0) => {
    const actIndex = acts.findIndex(a => a.id === actId);
    const act = acts[actIndex];
    if (!act) return;

    // Reset act state for new generation
    updateAct(actId, { 
      status: 'generating', 
      taskId: undefined, 
      videoUrl: undefined, 
      errorReason: undefined 
    });
    
    try {
      const finalPrompt = getFinalPrompt(act);
      const content: any[] = [
        { type: 'text', text: finalPrompt }
      ];

      // Helper to convert blob URL to base64
      const getBase64FromUrl = async (url: string) => {
        if (url.startsWith('data:') || url.startsWith('http')) return url;
        try {
          const response = await fetch(url);
          if (!response.ok) throw new Error('Network response was not ok');
          const blob = await response.blob();
          return new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        } catch (e) {
          console.warn("Could not convert URL to base64:", url);
          throw new Error("无法读取本地资产数据。由于浏览器安全限制，刷新页面后本地临时文件已被清理，请前往【1. 资产库】中删除该已失效的文件并重新上传。");
        }
      };

      // Add linked assets
      for (const link of act.linkedAssets) {
        const asset = assets.find(a => a.id === link.assetId);
        if (asset) {
          const rawUrl = asset.processedUrl || asset.originalUrl;
          let base64Url = await getBase64FromUrl(rawUrl);
          
          let publicUrl = rawUrl;
          if (base64Url.startsWith('data:')) {
            try {
              // Upload the base64 string to our proxy to relay to a true public image/audio host
              const res = await fetch('/api/upload-media', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mediaBase64: base64Url })
              });
              if (res.ok) {
                const data = await res.json();
                publicUrl = data.url; // Use the public relay URL
                console.log(`Successfully relayed ${asset.type} to public URL:`, publicUrl);
              } else {
                throw new Error(await res.text());
              }
            } catch (err: any) {
              console.error(`Failed to upload ${asset.type} to proxy:`, err);
              throw new Error(`无法将${asset.type === 'audio' ? '音频' : '图片'}上传到公网: ${err.message}`);
            }
          }
          
          if (!publicUrl.startsWith('http')) {
            throw new Error(`由于安全策略或网络问题，资产上传失败，无法提供公网URL (${publicUrl.substring(0, 30)}...)`);
          }

          if (asset.type === 'audio') {
            content.push({
              type: 'audio_url',
              audio_url: { url: publicUrl },
              role: 'reference_audio' // Seedance 2.0 audio reference
            });
          } else {
            content.push({
              type: 'image_url',
              image_url: { url: publicUrl },
              role: link.role || 'reference_image' // Seedance image reference
            });
          }
        }
      }

      const usingId = activeSeedanceModel === 'fast' ? apiKeys.seedanceFastId : apiKeys.seedanceId;

      const requestPayload = {
        model: usingId,
        content,
        duration: act.duration || 11,
        ratio: act.ratio || '16:9',
        generate_audio: true,
        watermark: true
      };

      console.log(`[Act ${actIndex + 1} Payload]:`, JSON.stringify(requestPayload, null, 2));

      addLog({ 
        type: 'info', 
        title: `发起视频生成 (幕 ${actIndex + 1}) ${retryCount > 0 ? `[重试 ${retryCount}]` : ''}`, 
        details: `Model: ${requestPayload.model}\nDuration: ${requestPayload.duration}s\nRatio: ${requestPayload.ratio}\nPrompt: ${finalPrompt}\nAssets: ${act.linkedAssets.length}个\nPayload JSON:\n${JSON.stringify(requestPayload, null, 2)}` 
      });

      const result = await generateSeedanceVideo(apiKeys.globalApiKey, requestPayload);

      if (result.taskId) {
        // Save the taskId and let TaskPoller take over
        updateAct(actId, { taskId: result.taskId, status: 'generating' });
        addLog({ 
          type: 'info', 
          title: `任务已提交 (幕 ${actIndex + 1})`, 
          details: `Task ID: ${result.taskId} - 正在后台排队生成中...` 
        });
      } else if (result.videoUrl) {
        addLog({ 
          type: 'success', 
          title: `视频生成成功 (幕 ${actIndex + 1})`, 
          details: `Video URL: ${result.videoUrl}` 
        });

        const history = [...(act.videoHistory || [])];
        if (act.videoUrl && !history.includes(act.videoUrl)) {
          history.push(act.videoUrl);
        }
        history.push(result.videoUrl);

        updateAct(actId, { 
          status: 'done', 
          videoUrl: result.videoUrl,
          videoHistory: [...new Set(history)]
        });
      }
    } catch (error: any) {
      console.error('Generation failed:', error);
      const isRealPersonError = error.message && error.message.toLowerCase().includes('real person');
      
      if (isRealPersonError && retryCount < 2) {
        addLog({ 
          type: 'warning', 
          title: `策略拦截 (幕 ${actIndex + 1})`, 
          details: `检测到可能包含真人，正在进行第 ${retryCount + 1} 次重试...` 
        });
        
        setTimeout(() => {
          handleGenerateVideo(actId, retryCount + 1);
        }, 1500);
        return;
      }
      
      const errorStr = isRealPersonError 
        ? `人脸识别拦截: 检测到疑似真人，已自动重试3次均失败。建议更换不含真人特征的参考图或修改提示词。\n原错误: ${error.message}`
        : `Error: ${error.message}`;

      addLog({ 
        type: 'error', 
        title: `生成失败 (幕 ${actIndex + 1})`, 
        details: `${errorStr}\nStack: ${error.stack || 'No stack trace'}` 
      });
      const reasonMsg = isRealPersonError ? '拦截: 疑似包含真人' : '接口错误或网络异常';
      updateAct(actId, { status: 'error', errorReason: reasonMsg });
      // Remove generic alert so we rely on UI state
    }
  };

  const handleBatchGenerate = () => {
    acts.forEach(act => {
      // Avoid re-triggering acts that are already working or succeeded
      if (act.status !== 'done' && act.status !== 'generating' && act.status !== 'queued') {
        enqueueGeneration(act.id);
      }
    });
  };

  const saveCurrentPrompt = (type: 'C') => {
    if (!newPromptName.trim()) return alert('请输入提示词名称');
    addSavedPrompt({
      name: newPromptName,
      content: prompts.fixedC,
      type
    });
    setNewPromptName('');
    alert('已保存到库');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('已复制到剪贴板');
  };

  const handleDragEnd = (result: any, actId: string) => {
    if (!result.destination) return;
    reorderLinkedAssets(actId, result.source.index, result.destination.index);
  };

  const startEditing = (act: any) => {
    setEditingActId(act.id);
    setTempShots(JSON.parse(JSON.stringify(act.customShots || act.shots)));
  };

  const saveEdits = (actId: string) => {
    updateAct(actId, { customShots: tempShots });
    setEditingActId(null);
  };

  const resolveTags = (templateString: string, act: any) => {
    if (!templateString) return '';
    const validLinks = act.linkedAssets.filter((l: any) => assets.some(a => a.id === l.assetId && a.type !== 'audio'));

    const getToken = (l: any) => {
      const i = validLinks.findIndex((vl: any) => vl.id === l.id);
      const asset = assets.find(a => a.id === l.assetId);
      const nameToUse = l.name && l.name.trim() !== '' ? l.name : (asset?.name || '资产');
      return `${nameToUse}参考图${i + 1}`;
    };

    const getCategoryTokens = (tag: '场景' | '服装' | '角色' | '全部') => {
      return validLinks.filter(l => {
         if (tag === '全部') return true;
         const asset = assets.find(a => a.id === l.assetId);
         if (!asset) return false;
         
         const searchStr = ((l.name || "") + " " + (asset.name || "") + " " + (asset.category || "")).toLowerCase();
         
         const isScene = searchStr.includes('场景') || searchStr.includes('环境');
         const isClothing = searchStr.includes('服装') || searchStr.includes('衣服') || searchStr.includes('穿搭');
         const isProp = searchStr.includes('道具');
         
         if (tag === '场景') return isScene;
         if (tag === '服装') return isClothing;
         if (tag === '角色') return !isScene && !isClothing && !isProp;
         return false;
      }).map((l) => {
         // Custom map logic for tags
         const i = validLinks.findIndex((vl: any) => vl.id === l.id);
         if (tag === '场景') {
           return `场景参考图${i + 1}`;
         }
         return getToken(l);
      }).filter(Boolean).join('，');
    };

    let resolved = templateString;
    
    resolved = resolved.replace(/\{全部资产\}/g, getCategoryTokens('全部'));
    resolved = resolved.replace(/\{关联资产\}/g, getCategoryTokens('全部')); // legacy fallback
    resolved = resolved.replace(/\{角色\}/g, getCategoryTokens('角色'));
    resolved = resolved.replace(/\{人物与服装\}/g, getCategoryTokens('角色')); // legacy fallback
    resolved = resolved.replace(/\{服装\}/g, getCategoryTokens('服装'));
    resolved = resolved.replace(/\{场景\}/g, getCategoryTokens('场景'));

    return resolved;
  };

  const getFinalPrompt = (act: any) => {
    const template = scenePrompts.find(p => p.id === act.scenePromptId) || scenePrompts[0] || { content: '' };
    const partA = resolveTags(template.content, act);
    const shots = act.customShots || act.shots;
    const shotText = shots.map((s: any) => s.description).join(' ');
    return `${partA} ${shotText} ${prompts.fixedC}`.trim();
  };

  const getResolvedScenePrompt = (act: any) => {
    const template = scenePrompts.find(p => p.id === act.scenePromptId) || scenePrompts[0] || { content: '' };
    return resolveTags(template.content, act);
  };

  const updateAssetRole = (actId: string, assetId: string, role: any) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    const newAssets = act.linkedAssets.map(la => 
      la.id === assetId ? { ...la, role } : la
    );
    updateAct(actId, { linkedAssets: newAssets });
  };

  const handleInsertTag = (idx: number, tag: string) => {
    const textarea = document.getElementById(`sp-textarea-${idx}`) as HTMLTextAreaElement;
    const newPrompts = [...scenePrompts];
    const sp = newPrompts[idx];

    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      sp.content = sp.content.substring(0, start) + tag + sp.content.substring(end);
      setScenePrompts(newPrompts);

      // Restore cursor position after state updates
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + tag.length, start + tag.length);
      }, 0);
    } else {
      sp.content += tag;
      setScenePrompts(newPrompts);
    }
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-6 text-zinc-100 pb-10">
      
      {/* Left: Settings & Prompts */}
      <div className="w-full lg:w-[350px] flex flex-col gap-4 shrink-0 overflow-y-auto custom-scrollbar pr-2 max-h-full">
        
        {/* Prompt Logic Section */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Settings2 className="text-indigo-400" size={20} />
              提示词管理
            </h2>
            <button 
              onClick={() => setShowPromptManager(true)}
              className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded border border-indigo-500/20 hover:bg-indigo-500/20 transition-all flex items-center gap-1"
            >
              <Bookmark size={10} /> 提示词库
            </button>
          </div>

          <div className="flex flex-col gap-3">
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 mb-1.5 uppercase tracking-wider">选择视频大模型</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveSeedanceModel('standard')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border transition-all ${activeSeedanceModel === 'standard' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
                >
                  Seedance 2.0
                </button>
                <button
                  onClick={() => setActiveSeedanceModel('fast')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border transition-all ${activeSeedanceModel === 'fast' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
                >
                  2.0 Fast
                </button>
              </div>
            </div>
            <div className="text-[10px] text-zinc-500 bg-zinc-950 p-2 rounded border border-zinc-800">
              <span className="font-bold text-zinc-400">注意:</span> 请确保在全局配置中分别填入了两个模型的推理 ID。
            </div>
          </div>

          {/* Scene Prompts (A) Section */}
          <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-950">
            <div className="px-4 py-3 flex items-center justify-between bg-zinc-900/30">
              <div className="flex items-center gap-2 text-indigo-300 text-sm font-medium">
                A: 场景预设提示词
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    const newPrompt = { id: Date.now().toString(), name: `A预设${scenePrompts.length + 1}`, content: '' };
                    setScenePrompts([...scenePrompts, newPrompt]);
                  }}
                  className="p-1 text-zinc-500 hover:text-indigo-400 bg-zinc-900 rounded"
                  title="新增场景提示词模板"
                >
                  <Plus size={14} />
                </button>
                <button onClick={() => setShowA(!showA)} className="p-1 text-zinc-500 hover:text-white">
                  {showA ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                </button>
              </div>
            </div>
            {showA && (
              <div className="p-4 border-t border-zinc-800 flex flex-col gap-4">
                <div className="text-[10px] text-zinc-400 bg-indigo-500/10 p-2.5 rounded-lg border border-indigo-500/20 leading-relaxed">
                  <span className="font-bold text-indigo-300">💡 动态变量说明：</span><br/>
                  点击下方的快捷按钮可插入对应标签，系统将在最终生成的 Prompt 里自动替换为真实的图片位置信息。<br/>
                  <span className="opacity-70 mt-1 block">示例输出：<br/>"{`场景:白天，室外，{场景}；{角色}`}" ➡️<br/>"场景:白天，室外，赛博街道参考图1；女主参考图2，林黛玉服装参考图3"</span>
                </div>
                
                <div className="flex flex-col gap-3 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                  {scenePrompts.map((sp, idx) => (
                    <div key={sp.id} className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-3 flex flex-col gap-2 relative group">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-zinc-500 font-mono">#{idx + 1}</span>
                        <input
                          type="text"
                          value={sp.name}
                          onChange={(e) => {
                            const newPrompts = [...scenePrompts];
                            newPrompts[idx].name = e.target.value;
                            setScenePrompts(newPrompts);
                          }}
                          className="flex-1 bg-transparent border-none p-0 text-xs font-semibold text-zinc-300 focus:outline-none focus:ring-0"
                          placeholder="提示词名称..."
                        />
                        {scenePrompts.length > 1 && (
                          <button 
                            onClick={() => {
                              if(confirm('确定删除此预设吗？')) {
                                setScenePrompts(scenePrompts.filter(p => p.id !== sp.id));
                              }
                            }}
                            className="text-zinc-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash2 size={12} />
                          </button>
                        )}
                      </div>
                      <textarea
                        id={`sp-textarea-${idx}`}
                        value={sp.content}
                        onChange={(e) => {
                          const newPrompts = [...scenePrompts];
                          newPrompts[idx].content = e.target.value;
                          setScenePrompts(newPrompts);
                        }}
                        className="w-full h-20 bg-zinc-950 border border-zinc-800/50 rounded-md p-2 text-[10px] focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-400 custom-scrollbar resize-none"
                        placeholder="在此处输入场景提示词..."
                      />
                      <div className="flex flex-wrap items-center gap-1.5 mt-1">
                        <span className="text-[10px] text-zinc-600 mr-1">快捷插入:</span>
                        <button 
                          onClick={() => handleInsertTag(idx, '{全部资产}')} 
                          className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded hover:bg-indigo-500/20 transition-all"
                        >+ 全部资产</button>
                        <button 
                          onClick={() => handleInsertTag(idx, '{角色}')} 
                          className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded hover:bg-indigo-500/20 transition-all"
                        >+ 角色</button>
                        <button 
                          onClick={() => handleInsertTag(idx, '{服装}')} 
                          className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded hover:bg-indigo-500/20 transition-all"
                        >+ 服装</button>
                        <button 
                          onClick={() => handleInsertTag(idx, '{场景}')} 
                          className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded hover:bg-indigo-500/20 transition-all"
                        >+ 场景</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* C Section */}
          <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-950">
            <div className="px-4 py-3 flex items-center justify-between bg-zinc-900/30">
              <div className="flex items-center gap-2 text-orange-300 text-sm font-medium">
                C: 固定参数
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setShowC(!showC)} className="p-1 text-zinc-500 hover:text-white">
                  {showC ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                </button>
              </div>
            </div>
            {showC && (
              <div className="p-4 border-t border-zinc-800">
                <textarea
                  value={prompts.fixedC}
                  onChange={(e) => updatePrompts({ fixedC: e.target.value })}
                  className="w-full h-20 bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 custom-scrollbar"
                />
                <div className="flex items-center gap-2 mt-3">
                  <input 
                    type="text" 
                    placeholder="存入库的名称..." 
                    value={newPromptName}
                    onChange={(e) => setNewPromptName(e.target.value)}
                    className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-[10px] focus:outline-none"
                  />
                  <button 
                    onClick={() => saveCurrentPrompt('C')}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1"
                  >
                    <Save size={10} /> 存入库
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Act Generation List */}
      <div className="flex-1 bg-zinc-900/30 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
          <h3 className="font-semibold text-zinc-200 flex items-center gap-2">
            <Zap size={18} className="text-yellow-400" />
            生成队列 ({acts.length} 幕)
          </h3>
          <button 
            onClick={handleBatchGenerate}
            disabled={acts.length === 0 || acts.every(a => a.status === 'done')}
            className="text-xs flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg transition-colors disabled:opacity-50 font-medium shadow-lg shadow-indigo-500/20"
          >
            <Film size={14} /> 批量生成视频
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 flex flex-col gap-10">
          {acts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 gap-3">
              <Film size={48} className="opacity-20" />
              <p>请先在“分镜生成”步骤中准备分镜脚本</p>
            </div>
          ) : (
            acts.map((act, idx) => (
              <div key={act.id} className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 flex flex-col gap-6 group transition-all hover:border-zinc-700">
                
                {/* Header */}
                <div className="flex items-center justify-between border-b border-zinc-800/50 pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 shrink-0 bg-indigo-500/10 text-indigo-400 rounded-xl flex items-center justify-center font-bold text-lg border border-indigo-500/20">
                      {idx + 1}
                    </div>
                    <div>
                      <h4 className="font-semibold text-zinc-100">{act.title}</h4>
                      <div className="flex flex-wrap items-center gap-3 mt-1">
                        <p className="text-[10px] text-zinc-500">ID: {act.id.slice(0,8)}...</p>
                        
                        {/* Duration */}
                        <div className="flex items-center gap-1.5 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800" title="视频时长 (4-15秒)">
                          <Clock size={10} className="text-zinc-500" />
                          <select 
                            value={act.duration || 11}
                            onChange={(e) => updateAct(act.id, { duration: parseInt(e.target.value) })}
                            className="bg-black text-[10px] text-zinc-300 focus:outline-none border border-zinc-800 rounded px-1"
                          >
                            {[...Array(12)].map((_, i) => i + 4).map(sec => (
                              <option key={sec} value={sec}>{sec}</option>
                            ))}
                          </select>
                          <span className="text-[10px] text-zinc-600">秒</span>
                        </div>

                        {/* Ratio */}
                        <div className="flex items-center gap-1.5 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                          <Maximize2 size={10} className="text-zinc-500" />
                          <select 
                            value={act.ratio || '16:9'}
                            onChange={(e) => updateAct(act.id, { ratio: e.target.value as any })}
                            className="bg-black text-[10px] text-zinc-300 focus:outline-none border border-zinc-800 rounded px-1"
                          >
                            <option value="21:9">21:9</option>
                            <option value="16:9">16:9</option>
                            <option value="4:3">4:3</option>
                            <option value="1:1">1:1</option>
                            <option value="3:4">3:4</option>
                            <option value="9:16">9:16</option>
                          </select>
                        </div>

                        {/* Resolution */}
                        <div className="flex items-center gap-1.5 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                          <Tag size={10} className="text-zinc-500" />
                          <select 
                            value={act.resolution || '720p'}
                            onChange={(e) => updateAct(act.id, { resolution: e.target.value as any })}
                            className="bg-black text-[10px] text-zinc-300 focus:outline-none border border-zinc-800 rounded px-1"
                          >
                            <option value="480p">480p</option>
                            <option value="720p">720p</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-2">
                    {act.status === 'idle' && (
                      <button 
                        onClick={() => enqueueGeneration(act.id)}
                        className="bg-zinc-800 hover:bg-indigo-600 text-zinc-300 hover:text-white px-5 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 shadow-sm"
                      >
                        <Play size={14} /> 生成该幕 ({act.duration || 10}s)
                      </button>
                    )}
                    {act.status === 'queued' && (
                      <div className="flex items-center gap-3">
                        <div className="text-yellow-400 flex items-center gap-2 text-xs font-semibold bg-yellow-500/10 px-5 py-2.5 rounded-xl border border-yellow-500/20">
                          <Loader2 size={14} className="animate-spin" /> 排队中...
                        </div>
                        <button
                          onClick={() => updateAct(act.id, { status: 'idle' })}
                          className="bg-zinc-800 hover:bg-red-600/80 text-zinc-300 hover:text-white px-4 py-2.5 rounded-xl text-xs font-semibold transition-all shadow-sm border border-zinc-700"
                          title="取消排队"
                        >
                          取消
                        </button>
                      </div>
                    )}
                    {act.status === 'generating' && (
                      <div className="flex items-center gap-3">
                        <div className="text-indigo-400 flex items-center gap-2 text-xs font-semibold bg-indigo-500/10 px-5 py-2.5 rounded-xl border border-indigo-500/20">
                          <Loader2 size={14} className="animate-spin" /> 生成中...
                        </div>
                        <button
                          onClick={() => updateAct(act.id, { status: 'idle' })}
                          className="bg-zinc-800 hover:bg-red-600/80 text-zinc-300 hover:text-white px-4 py-2.5 rounded-xl text-xs font-semibold transition-all shadow-sm border border-zinc-700"
                          title="取消生成任务"
                        >
                          取消
                        </button>
                      </div>
                    )}
                    {act.status === 'error' && (
                      <div className="flex items-center gap-3">
                        <div 
                          className="text-red-400 flex items-center gap-2 text-xs font-semibold bg-red-500/10 px-4 py-2.5 rounded-xl border border-red-500/20"
                          title={act.errorReason || '生成失败'}
                        >
                          <AlertCircle size={14} /> 生成失败 
                          {act.errorReason && <span className="opacity-70 font-normal">({act.errorReason})</span>}
                        </div>
                        <button 
                          onClick={() => enqueueGeneration(act.id)}
                          className="bg-zinc-800 hover:bg-indigo-600 text-zinc-300 hover:text-white px-4 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 shadow-sm border border-zinc-700"
                        >
                          <RefreshCw size={14} /> 重试生成
                        </button>
                      </div>
                    )}
                    {act.status === 'done' && (
                      <div className="flex items-center gap-3">
                        <div className="text-green-400 flex items-center gap-2 text-xs font-semibold bg-green-500/10 px-4 py-2.5 rounded-xl border border-green-500/20">
                          <Film size={14} /> 已完成
                        </div>
                        <button 
                          onClick={() => enqueueGeneration(act.id)}
                          className="bg-zinc-800 hover:bg-indigo-600 text-zinc-300 hover:text-white px-4 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 shadow-sm border border-zinc-700"
                        >
                          <RefreshCw size={14} /> 重新生成
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Scene A Prompt (Act Specific) Select */}
                <div className="flex flex-col gap-2 pt-2 border-t border-zinc-800/50">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">本幕专属起手提示词 (sceneA)</span>
                  </div>
                  <select
                    value={act.scenePromptId || scenePrompts[0]?.id || ''}
                    onChange={(e) => updateAct(act.id, { scenePromptId: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300"
                  >
                    {scenePrompts.map(sp => (
                      <option key={sp.id} value={sp.id}>{sp.name}</option>
                    ))}
                  </select>
                </div>

                {/* Reference Images (Above Storyboard) */}
                <div className="flex flex-col gap-2 pt-4 border-t border-zinc-800/50">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">参考资产 (拖动排序 & 设置角色)</span>
                  </div>
                  <DragDropContext onDragEnd={(result) => handleDragEnd(result, act.id)}>
                    <Droppable droppableId={`assets-${act.id}`} direction="horizontal">
                      {(provided) => (
                        <div 
                          {...provided.droppableProps} 
                          ref={provided.innerRef}
                          className="flex flex-wrap gap-3 p-3 bg-zinc-900/20 border border-zinc-800/50 rounded-xl min-h-[100px]"
                        >
                          {act.linkedAssets.length === 0 ? (
                            <div className="w-full flex items-center justify-center text-zinc-700 text-[10px] italic">暂无关联资产</div>
                          ) : (
                            act.linkedAssets.map((link, lIdx) => {
                              const asset = assets.find(a => a.id === link.assetId);
                              if (!asset) return null;
                              
                              // Calculate a contiguous display index among only the valid linked assets
                              const validLinks = act.linkedAssets.filter(l => assets.some(a => a.id === l.assetId));
                              const displayIndex = validLinks.findIndex(v => v.id === link.id) + 1;
                              
                              return (
                                // @ts-ignore
                                <Draggable key={link.id} draggableId={link.id} index={lIdx}>
                                  {(provided, snapshot) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      {...provided.dragHandleProps}
                                      className={`relative group/item cursor-grab active:cursor-grabbing ${snapshot.isDragging ? 'z-50' : ''}`}
                                    >
                                      <div className={`w-24 h-32 rounded-lg overflow-hidden border-2 transition-all flex flex-col ${snapshot.isDragging ? 'border-indigo-500 shadow-2xl scale-110' : 'border-zinc-800 group-hover/item:border-zinc-600'}`}>
                                        <div className="relative flex-1 bg-zinc-950 flex flex-col items-center justify-center">
                                          {asset.type === 'audio' ? (
                                            <div className="flex flex-col items-center gap-2 text-indigo-400">
                                              <PlayCircle size={24} />
                                              <span className="text-[10px] text-zinc-500 font-mono">Audio</span>
                                            </div>
                                          ) : (
                                            <>
                                              <img 
                                                src={asset.processedUrl || asset.originalUrl} 
                                                alt={asset.name} 
                                                className="w-full h-full object-cover"
                                              />
                                              <div className="absolute top-1 right-1 opacity-0 group-hover/item:opacity-100 transition-opacity">
                                                <button 
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setPreviewImage(asset.processedUrl || asset.originalUrl);
                                                  }}
                                                  className="p-1 bg-black/60 rounded text-white hover:bg-indigo-600 transition-colors"
                                                >
                                                  <Maximize2 size={10} />
                                                </button>
                                              </div>
                                            </>
                                          )}
                                          <div className={`absolute top-1 left-1 ${asset.type === 'audio' ? 'bg-emerald-600/90' : 'bg-indigo-600/90'} text-white text-[8px] font-bold px-1.5 py-0.5 rounded shadow-sm`}>
                                            {asset.type === 'audio' ? `音频${displayIndex}` : `图${displayIndex}`}
                                          </div>
                                        </div>
                                        <div className="bg-zinc-900 px-1 py-1 flex flex-col gap-1">
                                          <div className="text-[8px] text-zinc-500 font-bold text-center uppercase truncate">{asset.name}</div>
                                          {asset.type === 'image' ? (
                                            <select 
                                              value={link.role || 'reference_image'}
                                              onChange={(e) => updateAssetRole(act.id, link.id, e.target.value)}
                                              className="bg-zinc-950 text-[8px] text-zinc-300 rounded border border-zinc-800 px-1 py-0.5 focus:outline-none"
                                            >
                                              <option value="reference_image">参考图</option>
                                              <option value="first_frame">首帧</option>
                                              <option value="last_frame">尾帧</option>
                                            </select>
                                          ) : (
                                            <div className="bg-zinc-950 text-[8px] text-emerald-400 rounded border border-emerald-900/50 px-1 py-0.5 text-center truncate">
                                              配音/配乐
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </Draggable>
                              );
                            })
                          )}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </DragDropContext>
                </div>
                
                {/* Storyboard Preview / Edit Area */}
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">分镜内容预览</span>
                    {editingActId === act.id ? (
                      <button 
                        onClick={() => saveEdits(act.id)}
                        className="text-[10px] bg-green-500/10 text-green-400 px-2 py-1 rounded border border-green-500/20 hover:bg-green-500/20 transition-all flex items-center gap-1"
                      >
                        <Save size={10} /> 保存修改
                      </button>
                    ) : (
                      <button 
                        onClick={() => startEditing(act)}
                        className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-1 rounded border border-zinc-700 hover:text-white hover:bg-zinc-700 transition-all flex items-center gap-1"
                      >
                        <Edit3 size={10} /> 编辑分镜
                      </button>
                    )}
                  </div>

                  <div className="bg-zinc-900/50 rounded-xl p-4 border border-zinc-800 flex flex-col gap-3 min-h-[100px]">
                    {(editingActId === act.id ? tempShots : (act.customShots || act.shots)).map((shot, sIdx) => (
                      <div key={shot.id} className="flex gap-3">
                        <span className="text-zinc-600 font-mono text-xs mt-2 shrink-0 w-6 text-right">{idx+1}-{sIdx+1}</span>
                        {editingActId === act.id ? (
                          <textarea 
                            value={shot.description}
                            onChange={(e) => {
                              const newShots = [...tempShots];
                              newShots[sIdx].description = e.target.value;
                              setTempShots(newShots);
                            }}
                            className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-sm text-zinc-200 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 min-h-[60px] resize-none"
                          />
                        ) : (
                          <div className="flex-1 text-sm text-zinc-300 leading-relaxed py-1">
                            {shot.description || <span className="text-zinc-600 italic">空分镜</span>}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  {/* Final Prompt Preview */}
                  <div className="mt-2 text-left">
                    <button 
                      onClick={() => setExpandedPromptActId(expandedPromptActId === act.id ? null : act.id)}
                      className="w-full flex items-center justify-between text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-1 hover:text-zinc-300 transition-colors"
                    >
                      <span>最终发送给 Seedance 的 Prompt 预览 (点击展开全部)</span>
                      {expandedPromptActId === act.id ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                    </button>
                    {expandedPromptActId === act.id && (
                      <div 
                        className="bg-zinc-950 p-3 rounded-lg border border-zinc-800/50 text-[10px] font-mono leading-relaxed max-h-[500px] overflow-y-auto mt-2"
                      >
                        <div className="whitespace-pre-wrap break-all">
                          {getResolvedScenePrompt(act) ? (
                            <span className="text-indigo-400 font-bold">{getResolvedScenePrompt(act)}</span>
                          ) : prompts.systemA && (
                            <span className="text-indigo-400">{prompts.systemA}</span>
                          )}
                          <span className="text-zinc-300">
                            {' '}
                            {(act.customShots || act.shots).map((s: any) => s.description).join(' ')}
                            {' '}
                          </span>
                          {prompts.fixedC && <span className="text-orange-400">{prompts.fixedC}</span>}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            ))
          )}
        </div>
      </div>

      {/* Prompt Manager Sidebar/Modal */}
      {showPromptManager && (
        <div className="fixed inset-0 z-[60] flex items-center justify-end bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md h-full bg-zinc-950 border-l border-zinc-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
            <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
              <h3 className="font-semibold text-zinc-100 flex items-center gap-2">
                <Bookmark size={18} className="text-indigo-400" /> 提示词库
              </h3>
              <button onClick={() => setShowPromptManager(false)} className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar flex flex-col gap-6">
              {['A', 'C'].map((type) => (
                <div key={type} className="flex flex-col gap-3">
                  <h4 className={`text-xs font-bold uppercase tracking-widest ${type === 'A' ? 'text-indigo-400' : 'text-orange-400'}`}>
                    {type === 'A' ? '系统提示词 (A)' : '固定参数 (C)'}
                  </h4>
                  <div className="flex flex-col gap-2">
                    {savedPrompts.filter(p => p.type === type).length === 0 ? (
                      <div className="text-[10px] text-zinc-600 italic p-4 border border-dashed border-zinc-800 rounded-xl text-center">暂无保存的提示词</div>
                    ) : (
                      savedPrompts.filter(p => p.type === type).map(prompt => (
                        <div key={prompt.id} className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-3 flex flex-col gap-2 group hover:border-zinc-700 transition-all">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-zinc-200">{prompt.name}</span>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button 
                                onClick={() => {
                                  updatePrompts(type === 'A' ? { systemA: prompt.content } : { fixedC: prompt.content });
                                  alert('已应用');
                                }}
                                className="p-1.5 text-indigo-400 hover:bg-indigo-500/10 rounded"
                                title="应用"
                              >
                                <Zap size={12} />
                              </button>
                              <button 
                                onClick={() => copyToClipboard(prompt.content)}
                                className="p-1.5 text-zinc-400 hover:bg-zinc-800 rounded"
                                title="复制"
                              >
                                <Copy size={12} />
                              </button>
                              <button 
                                onClick={() => removeSavedPrompt(prompt.id)}
                                className="p-1.5 text-red-400 hover:bg-red-500/10 rounded"
                                title="删除"
                              >
                                <Trash2 size={12} />
                              </button>
                            </div>
                          </div>
                          <p className="text-[10px] text-zinc-500 line-clamp-2 font-mono">{prompt.content}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {previewImage && (
        <div 
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 backdrop-blur-md p-10 cursor-zoom-out"
          onClick={() => setPreviewImage(null)}
        >
          <img src={previewImage} alt="Preview" className="max-w-full max-h-full object-contain shadow-2xl rounded-lg" />
          <button className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all">
            <X size={24} />
          </button>
        </div>
      )}

    </div>
  );
}
