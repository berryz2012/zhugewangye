import React, { useState } from 'react';
import { useStore } from '@/store/useStore';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Settings, Wand2, Plus, Trash2, ChevronDown, ChevronRight, Loader2, Save, X, Image as ImageIcon, AlignLeft, GripVertical, FileText, Upload, Edit3, Users, HelpCircle, Eye } from 'lucide-react';

export default function StoryboardGenerator() {
  const { prompts, updatePrompts, apiKeys, acts, setActs, updateAct, assets, favoritedAssetIds, reorderActs, addLog, clearAllShots, clearStory, updateApiKeys, shortStoryText, setShortStoryText, longScriptText, setLongScriptText } = useStore();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(true);
  const [provider, setProvider] = useState<'doubao' | 'deepseek'>('doubao');
  const [mode, setMode] = useState<'short' | 'long'>('short');
  
  const currentText = mode === 'short' ? shortStoryText : longScriptText;
  const setCurrentText = mode === 'short' ? setShortStoryText : setLongScriptText;

  const helpUrl = "https://docs.volcengine.com/docs/ark/1255858";
  
  // Asset Selector Modal State
  const [selectorModal, setSelectorModal] = useState<{ isOpen: boolean, actId: string | null, characterName?: string, replaceLinkId?: string }>({ isOpen: false, actId: null });
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Boundary Editor State
  const [isBoundaryEditorOpen, setIsBoundaryEditorOpen] = useState(false);
  const [boundaryBlocks, setBoundaryBlocks] = useState<string[]>([]);
  const [splitPoints, setSplitPoints] = useState<number[]>([]); // Indices of blocks after which a split occurs
  const [isExtracting, setIsExtracting] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setCurrentText(event.target?.result as string);
    };
    reader.readAsText(file);
  };

  const handleGenerate = async () => {
    if (!currentText.trim()) return alert('请输入内容');
    setIsGenerating(true);
    
    try {
      const systemPrompt = mode === 'short' ? prompts.shortSplitPrompt : prompts.longSplitPrompt;
      const modelId = provider === 'doubao' ? apiKeys.doubaoId : apiKeys.deepseekId;
      const apiKey = apiKeys.globalApiKey;

      if (!apiKey || !modelId) {
        alert(`请先在全局配置中填写 API 密钥 和 ${provider === 'doubao' ? '豆包' : 'DeepSeek'} 的推理 ID`);
        setIsGenerating(false);
        return;
      }

      const payload = {
        provider,
        apiKey,
        modelId,
        systemPrompt,
        userKeywords: currentText,
      };

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) {
        addLog({ type: 'error', title: '生成失败', details: JSON.stringify(data, null, 2) });
        throw new Error(data.error || '生成失败');
      }

      addLog({ type: 'success', title: '剧本拆解成功', details: `Prompt:\n${systemPrompt}\n\nResponse:\n${data.result}` });

      const text = data.result;
      
      const start = text.indexOf('[');
      const end = text.lastIndexOf(']');
      if (start === -1 || end === -1) {
        throw new Error("AI未返回有效的JSON数组格式，请重试或修改提示词。");
      }
      
      const jsonStr = text.substring(start, end + 1);
      const parsedActs = JSON.parse(jsonStr);

      if (!Array.isArray(parsedActs)) {
        throw new Error("AI返回的不是数组格式");
      }

      const newActs = parsedActs.map((a: any, idx: number) => ({
        id: Date.now().toString() + idx,
        index: idx,
        title: a.title || `第 ${idx + 1} 幕`,
        originalText: a.originalText || '',
        characters: Array.isArray(a.characters) ? a.characters : [],
        shotsGenerated: mode === 'short', // short mode generates shots directly
        shots: Array.isArray(a.shots) ? a.shots.map((s: any, sIdx: number) => ({
          id: Date.now().toString() + '_' + idx + '_' + sIdx,
          description: s.description || ''
        })) : [],
        linkedAssets: [],
        status: 'idle' as const,
        duration: 10,
        resolution: '720p' as const,
        ratio: '16:9' as const
      }));

      setActs(newActs);
    } catch (err: any) {
      console.error(err);
      alert(`生成失败: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateShots = async (actId: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act || !act.originalText) return;
    
    updateAct(actId, { status: 'generating' });
    try {
      const modelId = provider === 'doubao' ? apiKeys.doubaoId : apiKeys.deepseekId;
      const apiKey = apiKeys.globalApiKey;

      if (!apiKey || !modelId) {
        alert(`请先在全局配置中填写 API 密钥 和 ${provider === 'doubao' ? '豆包' : 'DeepSeek'} 的 推理 ID`);
        updateAct(actId, { status: 'idle' });
        return;
      }

      const payload = {
        provider,
        apiKey,
        modelId,
        systemPrompt: prompts.actToShotsPrompt,
        userKeywords: act.originalText,
      };

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) {
        addLog({ type: 'error', title: `生成分镜失败 (幕 ${act.index + 1})`, details: JSON.stringify(data, null, 2) });
        throw new Error(data.error || '生成失败');
      }

      addLog({ type: 'success', title: `生成分镜成功 (幕 ${act.index + 1})`, details: `Prompt:\n${prompts.actToShotsPrompt}\n\nResponse:\n${data.result}` });

      const text = data.result;
      const start = text.indexOf('[');
      const end = text.lastIndexOf(']');
      if (start === -1 || end === -1) throw new Error("AI未返回有效的JSON数组格式");
      
      const parsedShots = JSON.parse(text.substring(start, end + 1));
      if (!Array.isArray(parsedShots)) throw new Error("AI返回的不是数组格式");

      updateAct(actId, {
        shotsGenerated: true,
        status: 'idle',
        shots: parsedShots.map((s: any, sIdx: number) => ({
          id: Date.now().toString() + '_' + sIdx,
          description: s.description || ''
        }))
      });
    } catch (err: any) {
      alert(`生成分镜失败: ${err.message}`);
      updateAct(actId, { status: 'idle' });
    }
  };

  const handleReExtractCharacters = async (actId: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act || !act.originalText) return;

    setIsExtracting(actId);

    try {
      const systemPrompt = '提取以下文本中的关键人物名称，严格返回JSON数组格式，例如：["男主", "女主", "反派"]';
      const payload = {
        provider,
        apiKey: apiKeys.globalApiKey,
        modelId: provider === 'doubao' ? apiKeys.doubaoId : apiKeys.deepseekId,
        systemPrompt,
        userKeywords: act.originalText,
      };

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) {
        addLog({ type: 'error', title: `提取人物失败 (幕 ${act.index + 1})`, details: JSON.stringify(data, null, 2) });
        throw new Error(data.error || '提取失败');
      }

      addLog({ type: 'success', title: `提取人物成功 (幕 ${act.index + 1})`, details: `Response:\n${data.result}` });

      const text = data.result;
      const start = text.indexOf('[');
      const end = text.lastIndexOf(']');
      if (start === -1 || end === -1) throw new Error("无效的JSON格式");
      
      const parsedCharacters = JSON.parse(text.substring(start, end + 1));
      
      if (Array.isArray(parsedCharacters)) {
        updateAct(actId, { characters: parsedCharacters });
      }
    } catch (err: any) {
      console.error(err);
      alert(`提取失败: ${err.message}`);
    } finally {
      setIsExtracting(null);
    }
  };

  const openBoundaryEditor = () => {
    const blocks: string[] = [];
    const initialSplits: number[] = [];
    let currentBlockCount = 0;

    acts.forEach((act, i) => {
      // 过滤掉可能存在的旧分割线文字，避免干扰
      const actBlocks = (act.originalText || '')
        .split('\n')
        .map(t => t.trim())
        .filter(t => t && t !== '【幕分割线】');
      
      if (actBlocks.length > 0) {
        blocks.push(...actBlocks);
        if (i < acts.length - 1) {
          currentBlockCount += actBlocks.length;
          initialSplits.push(currentBlockCount - 1);
        }
      }
    });

    setBoundaryBlocks(blocks);
    setSplitPoints(initialSplits);
    setIsBoundaryEditorOpen(true);
  };

  const saveBoundaries = () => {
    const newActsData: string[] = [];
    let currentActText: string[] = [];
    
    boundaryBlocks.forEach((block, idx) => {
      currentActText.push(block);
      if (splitPoints.includes(idx)) {
        newActsData.push(currentActText.join('\n'));
        currentActText = [];
      }
    });
    if (currentActText.length > 0) {
      newActsData.push(currentActText.join('\n'));
    }

    const newActs = newActsData.map((text, idx) => {
      // Try to find existing act to preserve metadata if possible
      // This is tricky because indices changed. We'll just create new ones or map by index.
      const existingAct = acts[idx];
      if (existingAct && existingAct.originalText === text) {
        return existingAct;
      }
      return {
        id: Date.now().toString() + idx,
        index: idx,
        title: `第 ${idx + 1} 幕`,
        originalText: text,
        characters: [],
        shotsGenerated: false,
        shots: [],
        linkedAssets: [],
        status: 'idle' as const,
        duration: 10,
        resolution: '720p' as const,
        ratio: '16:9' as const
      };
    });
    
    setActs(newActs);
    setIsBoundaryEditorOpen(false);
  };

  const toggleSplitPoint = (index: number) => {
    if (splitPoints.includes(index)) {
      setSplitPoints(splitPoints.filter(i => i !== index));
    } else {
      setSplitPoints([...splitPoints, index].sort((a, b) => a - b));
    }
  };

  const updateBlockText = (index: number, text: string) => {
    const newBlocks = [...boundaryBlocks];
    newBlocks[index] = text;
    setBoundaryBlocks(newBlocks);
  };

  const removeBlock = (index: number) => {
    const newBlocks = boundaryBlocks.filter((_, i) => i !== index);
    setBoundaryBlocks(newBlocks);
    // Adjust split points
    const newSplits = splitPoints
      .filter(i => i !== index)
      .map(i => i > index ? i - 1 : i);
    setSplitPoints(newSplits);
  };

  const handleBoundaryDragEnd = (result: any) => {
    if (!result.destination) return;
    const sourceIdx = result.source.index;
    const destIdx = result.destination.index;
    
    if (sourceIdx === destIdx) return;

    const newBlocks = Array.from(boundaryBlocks);
    const [removed] = newBlocks.splice(sourceIdx, 1);
    newBlocks.splice(destIdx, 0, removed);
    setBoundaryBlocks(newBlocks);
    
    // Reset split points because indices are now invalid
    setSplitPoints([]);
  };

  const handleBatchGenerateShots = async () => {
    const pendingActs = acts.filter(a => !a.shotsGenerated);
    for (const act of pendingActs) {
      await handleGenerateShots(act.id);
    }
  };

  const handleAddAct = () => {
    const newAct = {
      id: Date.now().toString(),
      index: acts.length,
      title: `新幕 ${acts.length + 1}`,
      originalText: '',
      characters: [],
      shotsGenerated: mode === 'short',
      shots: [{ id: Date.now().toString() + '_s', description: '' }],
      linkedAssets: [],
      status: 'idle' as const,
      duration: 10,
      resolution: '720p' as const,
      ratio: '16:9' as const
    };
    setActs([...acts, newAct]);
  };

  const handleRemoveAct = (id: string) => {
    setActs(acts.filter(a => a.id !== id).map((a, i) => ({ ...a, index: i })));
  };

  const handleAddShot = (actId: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    updateAct(actId, {
      shots: [...act.shots, { id: Date.now().toString(), description: '' }]
    });
  };

  const handleRemoveShot = (actId: string, shotId: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    updateAct(actId, {
      shots: act.shots.filter(s => s.id !== shotId)
    });
  };

  const handleUpdateShot = (actId: string, shotId: string, description: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    updateAct(actId, {
      shots: act.shots.map(s => s.id === shotId ? { ...s, description } : s)
    });
  };

  const handleLinkAsset = (assetId: string) => {
    if (!selectorModal.actId) return;
    
    const asset = assets.find(a => a.id === assetId);
    if (!asset) return;

    if (selectorModal.characterName) {
      // Global Character Mapping Mode: Apply to ALL acts that require or already have this character
      const charName = selectorModal.characterName;
      
      const newActs = acts.map(act => {
        const isActiveAct = act.id === selectorModal.actId;
        const hasExtractedChar = act.characters?.includes(charName);
        const existingLinkIndex = act.linkedAssets.findIndex(l => l.name === charName);
        
        if (isActiveAct || hasExtractedChar || existingLinkIndex !== -1) {
          const newLinkedAssets = [...act.linkedAssets];
          if (existingLinkIndex !== -1) {
            // Update existing assignment everywhere
            newLinkedAssets[existingLinkIndex] = {
              ...newLinkedAssets[existingLinkIndex],
              assetId,
              type: asset.type
            };
          } else {
            // Add new assignment to acts that contain this character
            newLinkedAssets.push({
              id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
              assetId,
              name: charName,
              type: asset.type,
              role: 'reference_image' as const
            });
          }
          return { ...act, linkedAssets: newLinkedAssets };
        }
        return act;
      });
      setActs(newActs);
    } else {
      // Local binding logic (e.g., custom props/scenes not tied to a global character name)
      const act = acts.find(a => a.id === selectorModal.actId);
      if (!act) return;

      if (selectorModal.replaceLinkId) {
        updateAct(act.id, {
          linkedAssets: act.linkedAssets.map(link => 
            link.id === selectorModal.replaceLinkId 
              ? { ...link, assetId, name: asset.name, type: asset.type, role: link.role || 'reference_image' }
              : link
          )
        });
      } else {
        const newLink = {
          id: Date.now().toString(),
          assetId,
          name: asset.name,
          type: asset.type,
          role: 'reference_image' as const
        };
        updateAct(act.id, { linkedAssets: [...act.linkedAssets, newLink] });
      }
    }
    
    setSelectorModal({ isOpen: false, actId: null });
  };

  const handleUnlinkAsset = (actId: string, linkId: string) => {
    const act = acts.find(a => a.id === actId);
    if (!act) return;
    updateAct(actId, { linkedAssets: act.linkedAssets.filter(link => link.id !== linkId) });
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    reorderActs(result.source.index, result.destination.index);
  };

  const renderLinkedCards = (actId: string, linkedAssets: any[]) => {
    const act = acts.find(a => a.id === actId);
    const characters = act?.characters || [];

    return (
      <div className="flex flex-col gap-2 mt-2">
        {/* Character Quick Add Buttons */}
        {characters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {characters.map(char => (
              <button 
                key={char}
                onClick={() => setSelectorModal({ isOpen: true, actId, characterName: char })}
                className="text-[10px] bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 px-2 py-1 rounded border border-indigo-500/20 transition-colors flex items-center gap-1"
              >
                <Plus size={10} /> {char}
              </button>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {linkedAssets.map(link => {
            const asset = assets.find(a => a.id === link.assetId);
            if (asset) {
              return (
                <div key={link.id} className="flex items-center gap-2 bg-zinc-800/80 border border-zinc-700 rounded-lg p-1.5 pr-3 group relative">
                  <div 
                    className="w-8 h-8 rounded bg-zinc-900 overflow-hidden shrink-0 flex items-center justify-center cursor-pointer hover:ring-2 hover:ring-indigo-500 transition-all"
                    onClick={() => asset.type !== 'audio' && setPreviewImage(asset.processedUrl || asset.originalUrl)}
                  >
                    {asset.type === 'audio' ? (
                      <span className="text-xs text-zinc-500">🎵</span>
                    ) : (
                      <img src={asset.processedUrl || asset.originalUrl} alt={asset.name} className="w-full h-full object-cover" />
                    )}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-medium text-zinc-200">{link.name}</span>
                    <span className="text-[10px] text-zinc-500">{asset.category}</span>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
                    <button 
                      onClick={() => setSelectorModal({ isOpen: true, actId, replaceLinkId: link.id, characterName: link.name })}
                      className="p-1 text-zinc-400 hover:text-indigo-400"
                      title="更换资产"
                    >
                      <Edit3 size={12} />
                    </button>
                    <button 
                      onClick={() => handleUnlinkAsset(actId, link.id)} 
                      className="p-1 text-zinc-400 hover:text-red-400"
                      title="移除"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              );
            }
            return null;
          })}
          
          <button 
            onClick={() => setSelectorModal({ isOpen: true, actId })}
            className="flex items-center justify-center w-8 h-8 rounded-lg border border-dashed border-zinc-700 text-zinc-500 hover:text-zinc-300 hover:border-zinc-500 transition-colors self-center"
            title="关联人物/场景/道具/音频"
          >
            <Plus size={16} />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-6 text-zinc-100">
      
      {/* Left: Input & Settings */}
      <div className="w-full lg:w-[450px] flex flex-col gap-4 shrink-0 overflow-y-auto custom-scrollbar pr-2">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Wand2 className="text-indigo-400" size={20} />
              故事转分镜
            </h2>
          </div>

          <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800">
            <button 
              onClick={() => setMode('short')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'short' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              小故事转分镜 (15秒内)
            </button>
            <button 
              onClick={() => setMode('long')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'long' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              长剧本拆分 (多幕)
            </button>
          </div>
          
          <div className="flex-1 min-h-[200px] flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <div className="flex gap-2">
                {mode === 'long' && (
                  <>
                    <button 
                      onClick={() => document.getElementById('script-upload')?.click()}
                      className="text-xs flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition-colors"
                    >
                      <Upload size={14} /> 导入剧本 (txt/md)
                    </button>
                    <input id="script-upload" type="file" accept=".txt,.md" className="hidden" onChange={handleFileUpload} />
                  </>
                )}
              </div>
              {(currentText || '').trim() && (
                <button 
                  onClick={() => {
                    if (confirm('确定要清空文本吗？')) {
                      setCurrentText('');
                    }
                  }}
                  className="text-xs flex items-center gap-1 text-zinc-500 hover:text-red-400 transition-colors"
                >
                  <Trash2 size={14} /> 清空文本
                </button>
              )}
            </div>
            <textarea
              value={currentText || ''}
              onChange={(e) => setCurrentText(e.target.value)}
              placeholder={mode === 'short' ? "请输入15秒以内的短视频故事描述..." : "请输入长篇剧本文稿，AI 将自动将其拆分为多个15秒的幕(Act)..."}
              className="w-full h-full min-h-[200px] bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-zinc-200 placeholder:text-zinc-600 resize-none custom-scrollbar"
            />
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !(currentText || '').trim()}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-indigo-500/20"
          >
            {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Wand2 size={18} />}
            {isGenerating ? 'AI 拆解中...' : (mode === 'short' ? '生成分镜脚本' : '拆解故事内容')}
          </button>
        </div>

        {/* AI Settings */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col shrink-0">
          <div 
            className="w-full px-5 py-4 flex items-center justify-between text-sm font-bold text-zinc-100 bg-zinc-900/80 border-b border-zinc-800"
          >
            <div className="flex items-center gap-2 uppercase tracking-widest">
              <Settings size={16} className="text-indigo-400" />
              AI 拆解配置
            </div>
            <a 
              href={helpUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-1 px-2 text-[10px] text-zinc-500 hover:text-indigo-400 flex items-center gap-1 bg-zinc-800/50 rounded-md border border-zinc-700/50 transition-colors"
              title="查看 API 接入指南"
            >
              <HelpCircle size={14} /> API 接入教程
            </a>
          </div>
          
          <div className="p-5 flex flex-col gap-5">
            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">选择大模型</label>
                <div className="flex gap-2 mb-2">
                  <button
                    onClick={() => setProvider('doubao')}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all ${provider === 'doubao' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
                  >
                    豆包 (Doubao)
                  </button>
                  <button
                    onClick={() => setProvider('deepseek')}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all ${provider === 'deepseek' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
                  >
                    DeepSeek
                  </button>
                </div>
                <div className="text-[10px] text-zinc-500 bg-zinc-950 p-2 rounded border border-zinc-800">
                  <span className="font-bold text-zinc-400">注意:</span> 请确保已在"全局配置"中填写对应的 API 密钥和推理接入点 ID。
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">小故事拆分 Prompt</label>
                <textarea
                  value={prompts?.shortSplitPrompt || ''}
                  onChange={(e) => updatePrompts({ shortSplitPrompt: e.target.value })}
                  className="w-full h-24 bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-300 custom-scrollbar resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">长剧本拆分 Prompt (第一阶段)</label>
                <textarea
                  value={prompts?.longSplitPrompt || ''}
                  onChange={(e) => updatePrompts({ longSplitPrompt: e.target.value })}
                  className="w-full h-24 bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-400 custom-scrollbar resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-2 uppercase tracking-wider">场景转分镜 Prompt (第二阶段)</label>
                <textarea
                  value={prompts?.actToShotsPrompt || ''}
                  onChange={(e) => updatePrompts({ actToShotsPrompt: e.target.value })}
                  className="w-full h-24 bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all text-zinc-400 custom-scrollbar resize-none"
                />
              </div>

              <div className="pt-2">
                <button 
                  onClick={() => alert('已自动保存配置到浏览器缓存')}
                  className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-100 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all border border-zinc-700"
                >
                  <Save size={14} className="text-indigo-400" /> 保存当前全部配置
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right: Acts List */}
      <div className="flex-1 bg-zinc-900/30 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
          <h3 className="font-semibold text-zinc-200">分镜脚本 ({acts.length} 幕)</h3>
          <div className="flex items-center gap-3">
            {acts.length > 0 && (
              <button 
                onClick={() => {
                  if (confirm('确定要清空所有分镜吗？')) {
                    clearAllShots();
                  }
                }}
                className="text-xs flex items-center gap-1 text-zinc-500 hover:text-red-400 transition-colors"
              >
                <Trash2 size={14} /> 清空分镜
              </button>
            )}
            {mode === 'long' && acts.length > 0 && (
              <button 
                onClick={openBoundaryEditor}
                className="text-xs flex items-center gap-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-lg transition-colors"
              >
                <Edit3 size={14} /> 调整幕边界
              </button>
            )}
            {acts.some(a => !a.shotsGenerated) && (
              <button 
                onClick={handleBatchGenerateShots}
                className="text-xs flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-lg transition-colors"
              >
                <Wand2 size={14} /> 批量生成分镜
              </button>
            )}
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 flex flex-col gap-6">
          {acts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 gap-3">
              <AlignLeft size={48} className="opacity-20" />
              <p>在左侧输入故事并生成</p>
            </div>
          ) : (
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="acts-list">
                {(provided) => (
                  <div {...provided.droppableProps} ref={provided.innerRef} className="flex flex-col gap-6">
                    {acts.map((act, idx) => (
                      // @ts-ignore
                      <Draggable key={act.id} draggableId={act.id} index={idx}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`bg-zinc-950 border rounded-xl p-5 flex flex-col gap-4 group transition-all ${snapshot.isDragging ? 'border-indigo-500 shadow-2xl z-50' : 'border-zinc-800'}`}
                          >
                            {/* Act Header */}
                            <div className="flex items-center justify-between border-b border-zinc-800/50 pb-3">
                              <div className="flex items-center gap-3">
                                <div {...provided.dragHandleProps} className="text-zinc-600 hover:text-zinc-300 cursor-grab active:cursor-grabbing">
                                  <GripVertical size={18} />
                                </div>
                                <div className="w-8 h-8 shrink-0 bg-indigo-500/10 text-indigo-400 rounded-lg flex items-center justify-center font-bold text-sm border border-indigo-500/20">
                                  {idx + 1}
                                </div>
                                <input
                                  type="text"
                                  value={act.title}
                                  onChange={(e) => updateAct(act.id, { title: e.target.value })}
                                  className="bg-transparent border-none p-0 text-base font-medium focus:outline-none text-zinc-200"
                                />
                              </div>
                              <button 
                                onClick={() => handleRemoveAct(act.id)}
                                className="text-zinc-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all p-1"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>

                            {/* Linked Assets / Characters */}
                            <div className="bg-zinc-900/50 rounded-lg p-3 border border-zinc-800/50">
                              <div className="text-xs font-medium text-zinc-400 mb-1">包含元素 (人物/场景/道具/音频)：</div>
                              {renderLinkedCards(act.id, act.linkedAssets)}
                            </div>

                            {/* Content: Either Original Text (Stage 1) or Shots (Stage 2) */}
                            {!act.shotsGenerated ? (
                              <div className="flex flex-col gap-3">
                                <div className="text-xs font-medium text-zinc-400 flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <FileText size={14} /> 剧情原文 (可调整)
                                  </div>
                                  <button 
                                    onClick={() => handleReExtractCharacters(act.id)}
                                    disabled={isExtracting === act.id}
                                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors disabled:opacity-50"
                                  >
                                    {isExtracting === act.id ? <Loader2 size={12} className="animate-spin" /> : <Users size={12} />}
                                    重新提取人物
                                  </button>
                                </div>
                                <textarea
                                  value={act.originalText}
                                  onChange={(e) => updateAct(act.id, { originalText: e.target.value })}
                                  className="w-full bg-zinc-900/50 border border-zinc-800 rounded-lg p-3 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/50 text-zinc-300 resize-none h-24 custom-scrollbar"
                                />
                                <button 
                                  onClick={() => handleGenerateShots(act.id)}
                                  disabled={act.status === 'generating'}
                                  className="self-end bg-zinc-800 hover:bg-indigo-600 text-zinc-300 hover:text-white px-4 py-2 rounded-lg text-xs font-medium transition-colors flex items-center gap-2"
                                >
                                  {act.status === 'generating' ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />}
                                  {act.status === 'generating' ? '生成中...' : '生成分镜'}
                                </button>
                              </div>
                            ) : (
                              <div className="flex flex-col gap-2">
                                {act.originalText && (
                                  <details className="mb-2 group/details">
                                    <summary className="text-xs text-zinc-500 cursor-pointer hover:text-zinc-300 flex items-center gap-1 select-none">
                                      <ChevronRight size={14} className="group-open/details:rotate-90 transition-transform" />
                                      查看原文参考
                                    </summary>
                                    <div className="mt-2 p-3 bg-zinc-900/30 border border-zinc-800/50 rounded-lg text-xs text-zinc-400 leading-relaxed">
                                      {act.originalText}
                                    </div>
                                  </details>
                                )}
                                
                                {act.shots.map((shot, sIdx) => (
                                  <div key={shot.id} className="flex items-start gap-3 group/shot bg-zinc-900/30 p-3 rounded-xl border border-zinc-800/50 hover:border-zinc-700 transition-all">
                                    <div className="text-[10px] font-mono text-zinc-600 mt-2 shrink-0 w-6 text-right">
                                      {idx + 1}-{sIdx + 1}
                                    </div>
                                    <textarea
                                      value={shot.description}
                                      onChange={(e) => handleUpdateShot(act.id, shot.id, e.target.value)}
                                      placeholder="分镜画面描述..."
                                      className="flex-1 bg-transparent border-none p-0 text-sm focus:outline-none text-zinc-300 resize-none h-16 custom-scrollbar"
                                    />
                                    <button 
                                      onClick={() => handleRemoveShot(act.id, shot.id)}
                                      className="text-zinc-600 hover:text-red-400 opacity-0 group-hover/shot:opacity-100 transition-all shrink-0 p-1.5 bg-zinc-800/50 rounded-lg"
                                      title="删除此分镜"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  </div>
                                ))}
                                <div className="flex items-center gap-3 mt-1 ml-9">
                                  <button 
                                    onClick={() => handleAddShot(act.id)}
                                    className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
                                  >
                                    <Plus size={12} /> 添加分镜
                                  </button>
                                  <button 
                                    onClick={() => handleReExtractCharacters(act.id)}
                                    disabled={isExtracting === act.id}
                                    className="text-xs text-zinc-500 hover:text-indigo-400 flex items-center gap-1 transition-colors disabled:opacity-50"
                                  >
                                    {isExtracting === act.id ? <Loader2 size={12} className="animate-spin" /> : <Users size={12} />}
                                    筛查本幕角色
                                  </button>
                                  <button
                                    onClick={() => {
                                      if(confirm('重新生成将会覆盖当前本幕的所有分镜片段，确认继续吗？')) {
                                        handleGenerateShots(act.id);
                                      }
                                    }}
                                    disabled={act.status === 'generating'}
                                    className="text-xs text-orange-400 hover:text-orange-300 flex items-center gap-1 transition-colors disabled:opacity-50"
                                  >
                                    {act.status === 'generating' ? <Loader2 size={12} className="animate-spin" /> : <Wand2 size={12} />}
                                    根据原文重写分镜
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          )}
        </div>
      </div>

      {/* Boundary Editor Modal */}
      {isBoundaryEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl w-full max-w-5xl h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50 shrink-0">
              <div className="flex flex-col">
                <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
                  <Edit3 size={18} className="text-indigo-400" /> 可视化幕边界调整
                </h2>
                <p className="text-xs text-zinc-500">拖动文本块调整顺序，点击块之间的虚线进行分割或合并</p>
              </div>
              <button onClick={() => setIsBoundaryEditorOpen(false)} className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar bg-zinc-950/50">
              <DragDropContext onDragEnd={handleBoundaryDragEnd}>
                <Droppable droppableId="boundary-blocks">
                  {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef} className="max-w-3xl mx-auto flex flex-col">
                      {boundaryBlocks.map((block, idx) => (
                        <React.Fragment key={idx}>
                          <Draggable draggableId={`block-${idx}`} index={idx}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                className={`group relative mb-2 ${snapshot.isDragging ? 'z-50' : ''}`}
                              >
                                <div className={`bg-zinc-900/80 border rounded-xl p-4 transition-all ${snapshot.isDragging ? 'border-indigo-500 shadow-2xl scale-[1.02]' : 'border-zinc-800 hover:border-zinc-700'}`}>
                                  <div {...provided.dragHandleProps} className="absolute -left-8 top-1/2 -translate-y-1/2 text-zinc-700 hover:text-zinc-500 cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition-opacity">
                                    <GripVertical size={20} />
                                  </div>
                                  <textarea
                                    value={block}
                                    onChange={(e) => updateBlockText(idx, e.target.value)}
                                    className="w-full bg-transparent border-none p-0 text-sm focus:outline-none text-zinc-300 resize-none min-h-[40px] custom-scrollbar leading-relaxed"
                                    rows={Math.max(1, block.split('\n').length)}
                                  />
                                  <button 
                                    onClick={() => removeBlock(idx)}
                                    className="absolute -right-8 top-1/2 -translate-y-1/2 text-zinc-700 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <Trash2 size={16} />
                                  </button>
                                </div>
                              </div>
                            )}
                          </Draggable>

                          {idx < boundaryBlocks.length - 1 && (
                            <div className="relative h-8 flex items-center justify-center group/line">
                              <div 
                                className={`absolute inset-x-0 h-px transition-all ${splitPoints.includes(idx) ? 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]' : 'bg-zinc-800 group-hover/line:bg-zinc-600 border-t border-dashed border-zinc-700'}`}
                              />
                              <button
                                onClick={() => toggleSplitPoint(idx)}
                                className={`z-10 px-3 py-1 rounded-full text-[10px] font-bold transition-all flex items-center gap-1 ${
                                  splitPoints.includes(idx) 
                                    ? 'bg-indigo-600 text-white' 
                                    : 'bg-zinc-800 text-zinc-500 opacity-0 group-hover/line:opacity-100 hover:bg-zinc-700 hover:text-zinc-300'
                                }`}
                              >
                                {splitPoints.includes(idx) ? (
                                  <X size={10} />
                                ) : (
                                  <Plus size={10} />
                                )}
                              </button>
                              {splitPoints.includes(idx) && (
                                <div className="absolute -right-16 text-[10px] font-mono text-indigo-500/50 uppercase tracking-widest">
                                  
                                </div>
                              )}
                            </div>
                          )}
                        </React.Fragment>
                      ))}
                      {provided.placeholder}
                      
                      <button 
                        onClick={() => setBoundaryBlocks([...boundaryBlocks, ''])}
                        className="mt-4 w-full py-4 border-2 border-dashed border-zinc-800 rounded-xl text-zinc-600 hover:text-zinc-400 hover:border-zinc-600 transition-all flex items-center justify-center gap-2 text-sm"
                      >
                        <Plus size={18} /> 添加文本块
                      </button>
                    </div>
                  )}
                </Droppable>
              </DragDropContext>
            </div>

            <div className="p-6 border-t border-zinc-800 bg-zinc-900/30 flex justify-end gap-3 shrink-0">
              <button onClick={() => setIsBoundaryEditorOpen(false)} className="px-5 py-2.5 rounded-xl text-sm font-medium text-zinc-300 hover:text-white hover:bg-zinc-800 transition-all">
                取消
              </button>
              <button 
                onClick={saveBoundaries} 
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 transition-all shadow-lg shadow-indigo-500/20"
              >
                <Save size={18} /> 应用并重新生成幕结构
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Asset Selector Modal */}
      {selectorModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-2xl h-[60vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
              <h2 className="text-lg font-medium text-zinc-200 flex items-center gap-2">
                <ImageIcon size={18} className="text-indigo-400" />
                从收藏的资产中选择
              </h2>
              <button onClick={() => setSelectorModal({ isOpen: false, actId: null })} className="p-2 text-zinc-400 hover:text-zinc-200 rounded-lg">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {favoritedAssetIds.length === 0 ? (
                  <div className="col-span-full text-center text-zinc-500 py-10">
                    暂无收藏的资产，请前往第二步“资产库”收藏图片
                  </div>
                ) : (
                  favoritedAssetIds.map(id => {
                    const asset = assets.find(a => a.id === id);
                    if (!asset) return null;
                    return (
                      <div 
                        key={asset.id}
                        onClick={() => handleLinkAsset(asset.id)}
                        className="bg-zinc-900 border border-zinc-800 hover:border-indigo-500/50 rounded-xl overflow-hidden cursor-pointer transition-all group flex flex-col"
                      >
                        <div className="h-32 bg-zinc-950 relative flex items-center justify-center">
                          {asset.type === 'audio' ? (
                            <span className="text-4xl">🎵</span>
                          ) : (
                            <img src={asset.processedUrl || asset.originalUrl} alt={asset.name} className="w-full h-full object-cover" />
                          )}
                        </div>
                        <div className="p-3">
                          <div className="font-medium text-zinc-200 text-sm truncate group-hover:text-indigo-400 transition-colors">{asset.name}</div>
                          <div className="text-[10px] text-zinc-500 mt-1">{asset.category}</div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {previewImage && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-10 cursor-zoom-out"
          onClick={() => setPreviewImage(null)}
        >
          <img src={previewImage} alt="Preview" className="max-w-full max-h-full object-contain shadow-2xl rounded-lg" />
          <button className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all">
            <X size={24} />
          </button>
        </div>
      )}
    </div>
  );
}
